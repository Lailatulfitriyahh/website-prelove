<?php
// Aktifkan pelaporan kesalahan PHP untuk debugging.
// HAPUS atau NONAKTIFKAN BARIS INI DI LINGKUNGAN PRODUKSI!
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'koneksi.php'; // Hubungkan ke file koneksi database Anda

// --- Cek Koneksi Database ---
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// --- Pastikan pengguna sudah login ---
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Arahkan ke halaman login jika belum login
    exit();
}

$user_id = $_SESSION['user_id'];
$user_data = null; // Variabel untuk menyimpan data profil pengguna yang akan ditampilkan di form
$message = ""; // Variabel untuk pesan status atau error

// --- 1. Ambil Data Profil Pengguna untuk Diisi ke Form (Saat Halaman Pertama Kali Dimuat atau Setelah Gagal Update) ---
$stmt_fetch = mysqli_prepare($koneksi, "SELECT nama, email, no_hp, alamat FROM users WHERE id = ?");

if ($stmt_fetch) {
    mysqli_stmt_bind_param($stmt_fetch, "i", $user_id); // "i" for integer
    mysqli_stmt_execute($stmt_fetch);
    $result_fetch = mysqli_stmt_get_result($stmt_fetch);

    if ($result_fetch && mysqli_num_rows($result_fetch) > 0) {
        $user_data = mysqli_fetch_assoc($result_fetch);
    } else {
        $message = "Gagal memuat data profil Anda. Harap hubungi administrator.";
        error_log("Failed to fetch user profile for editing: " . mysqli_error($koneksi));
    }
    mysqli_stmt_close($stmt_fetch);
} else {
    $message = "Kesalahan persiapan pengambilan data profil: " . mysqli_error($koneksi);
    error_log("Failed to prepare fetch user profile query: " . mysqli_error($koneksi));
}

// --- 2. Proses Pembaruan Profil (Saat Form Disubmit Menggunakan Metode POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    // Ambil data yang dikirim dari form dan bersihkan
    $nama = trim($_POST['nama'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $no_hp = trim($_POST['no_hp'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');

    $errors = []; // Array untuk menyimpan kesalahan validasi

    // Validasi input
    if (empty($nama)) {
        $errors[] = "Nama lengkap tidak boleh kosong.";
    }
    if (empty($email)) {
        $errors[] = "Email tidak boleh kosong.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Format email tidak valid.";
    } else {
        // Cek apakah email sudah digunakan oleh pengguna lain (selain diri sendiri)
        $stmt_check_email = mysqli_prepare($koneksi, "SELECT id FROM users WHERE email = ? AND id != ?");
        if ($stmt_check_email) {
            mysqli_stmt_bind_param($stmt_check_email, "si", $email, $user_id);
            mysqli_stmt_execute($stmt_check_email);
            mysqli_stmt_store_result($stmt_check_email); // Simpan hasil agar bisa dihitung barisnya
            if (mysqli_stmt_num_rows($stmt_check_email) > 0) {
                $errors[] = "Email ini sudah digunakan oleh akun lain.";
            }
            mysqli_stmt_close($stmt_check_email);
        } else {
            error_log("Failed to prepare check email query: " . mysqli_error($koneksi));
            $errors[] = "Terjadi kesalahan saat memeriksa email.";
        }
    }
    // Tambahan validasi lain sesuai kebutuhan (misal: panjang no_hp, dll.)

    if (empty($errors)) {
        // Jika tidak ada error validasi, lanjutkan dengan update data di database
        // Query UPDATE menggunakan Prepared Statement untuk keamanan
        $stmt_update = mysqli_prepare($koneksi, "UPDATE users SET nama = ?, email = ?, no_hp = ?, alamat = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");

        if ($stmt_update) {
            // "ssssi" berarti 4 string (nama, email, no_hp, alamat) dan 1 integer (user_id)
            mysqli_stmt_bind_param($stmt_update, "ssssi", $nama, $email, $no_hp, $alamat, $user_id);
            if (mysqli_stmt_execute($stmt_update)) {
                $message = "Profil berhasil diperbarui!";
                // Setelah update berhasil, perbarui variabel $user_data
                // agar form menampilkan data yang baru saja disimpan
                $user_data['nama'] = $nama;
                $user_data['email'] = $email;
                $user_data['no_hp'] = $no_hp;
                $user_data['alamat'] = $alamat;
            } else {
                $message = "Gagal memperbarui profil: " . mysqli_stmt_error($stmt_update);
                error_log("Failed to update user profile: " . mysqli_stmt_error($stmt_update));
            }
            mysqli_stmt_close($stmt_update);
        } else {
            $message = "Kesalahan persiapan update profil: " . mysqli_error($koneksi);
            error_log("Failed to prepare update profile query: " . mysqli_error($koneksi));
        }
    } else {
        // Jika ada error validasi, gabungkan pesan error menjadi satu string
        $message = implode("<br>", $errors);
        // Penting: Jika ada error, data yang di-submit harus ditampilkan kembali di form
        // Kita perlu memastikan $user_data diisi dengan nilai yang baru disubmit
        $user_data['nama'] = $nama;
        $user_data['email'] = $email;
        $user_data['no_hp'] = $no_hp;
        $user_data['alamat'] = $alamat;
    }
}

// Tutup koneksi database setelah semua operasi selesai
if (isset($koneksi)) {
    mysqli_close($koneksi);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Edit Profil - Thriftpreelove</title>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
    <style>
        /* Gaya dasar */
        body {
            font-family: sans-serif;
            margin: 0;
            background-color: #f9f9f9;
        }

        /* Navbar Styling - Consistent with other pages */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: black;
            color: white;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .navbar .logo a {
            color: white;
            font-size: 20px;
            font-weight: bold;
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0 auto;
            flex-grow: 1;
            justify-content: center;
        }

        .nav-links li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .search-container-inline {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }

        .search-container-inline input[type="text"] {
            padding: 8px 15px;
            border: none;
            border-radius: 20px 0 0 20px;
            outline: none;
            width: 220px;
            background-color: white;
            color: #333;
            font-size: 16px;
        }

        .search-container-inline button {
            background-color: #e0b0ff;
            border: none;
            padding: 8px 15px;
            border-radius: 0 20px 20px 0;
            margin-left: -1px;
            cursor: pointer;
            color: black;
            transition: background-color 0.3s ease;
            font-size: 16px;
        }

        .search-container-inline button:hover {
            background-color: #cc99ff;
        }

        .nav-icons {
          display: flex;
          align-items: center;
          gap: 15px;
        }

        .nav-icons a {
          color: white;
          font-size: 18px;
          text-decoration: none;
          transition: color 0.3s ease;
        }

        .nav-icons a:hover {
          color: #e0b0ff;
        }

        .auth-links {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-left: 15px;
        }

        .auth-links a {
            background-color: #4a4a4a;
            padding: 8px 15px;
            border-radius: 8px;
            color: white;
            text-decoration: none;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 80px;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }

        .auth-links a:hover {
            background-color: #666;
            transform: translateY(-1px);
        }

        /* Gaya Khusus Halaman Edit Profil */
        .edit-profile-section {
            padding: 80px 20px;
            text-align: center;
            max-width: 600px;
            margin: 50px auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .edit-profile-section h2 {
            font-size: 2.5em;
            color: #333;
            margin-bottom: 25px;
        }

        .edit-profile-form {
            text-align: left;
            padding: 0 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group textarea {
            width: calc(100% - 22px); /* Full width with padding/border consideration */
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
            box-sizing: border-box;
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .update-button {
            background-color: #e0b0ff;
            border: none;
            padding: 12px 25px;
            border-radius: 25px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            color: black;
            font-size: 1.1em;
            transition: background-color 0.3s ease;
            width: 100%;
            margin-top: 20px;
        }

        .update-button:hover {
            background-color: #cc99ff;
        }

        .back-button {
            background-color: #555;
            color: white;
            padding: 12px 25px;
            border-radius: 25px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 1.1em;
            transition: background-color 0.3s ease;
            width: 100%;
            display: block; /* Make it a block element to take full width */
            text-align: center;
            margin-top: 10px;
        }

        .back-button:hover {
            background-color: #777;
        }

        .status-message {
            background-color: #d4edda; /* Light green for success */
            color: #155724; /* Dark green text */
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }

        .status-message.error {
            background-color: #f8d7da; /* Light red for errors */
            color: #721c24; /* Dark red text */
        }

        /* Footer */
        footer {
            background-color: #222;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 40px;
        }
    </style>
</head>
<body>

    <header>
        <nav class="navbar">
            <div class="logo">
                <a href="index.html#home">thriftpreelove.</a>
            </div>
            <ul class="nav-links">
                <li><a href="index.html#home">Home</a></li>
                <li><a href="index.html#tentang-kami">Tentang Kami</a></li>
                <li><a href="produk.php">Produk</a></li>
                <li><a href="index.html#kontak">Kontak</a></li>
            </ul>

            <div class="search-container-inline">
                <form action="search.php" method="GET" style="display: flex;">
                    <input type="text" name="query" placeholder="Cari produk...">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>

            <div style="display: flex; align-items: center">
                <div class="nav-icons">
                    <a href="cart.php" class="cart-icon" title="Lihat Keranjang">
                        <i class="fas fa-shopping-cart"></i>
                    </a>
                </div>

                <div class="auth-links">
                    <a href="profile.php">Profil</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="edit-profile-section">
            <h2>Edit Profil Anda</h2>

            <?php if (!empty($message)): ?>
                <p class="status-message <?php echo (strpos($message, 'berhasil') !== false) ? 'success' : 'error'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </p>
            <?php endif; ?>

            <?php if ($user_data): ?>
            <form action="edit_profile.php" method="POST" class="edit-profile-form">
                <div class="form-group">
                    <label for="nama">Nama Lengkap:</label>
                    <input type="text" id="nama" name="nama" value="<?php echo htmlspecialchars($user_data['nama'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="no_hp">Nomor Telepon:</label>
                    <input type="text" id="no_hp" name="no_hp" value="<?php echo htmlspecialchars($user_data['no_hp'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="alamat">Alamat:</label>
                    <textarea id="alamat" name="alamat"><?php echo htmlspecialchars($user_data['alamat'] ?? ''); ?></textarea>
                </div>
                <button type="submit" name="update_profile" class="update-button">Perbarui Profil</button>
            </form>
            <a href="profile.php" class="back-button">Kembali ke Profil</a>
            <?php else: ?>
                <p>Tidak dapat memuat data profil. Silakan coba lagi atau hubungi dukungan.</p>
                <a href="profile.php" class="back-button">Kembali ke Profil</a>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> Thriftpreelove. Semua Hak Dilindungi.</p>
        </div>
    </footer>
</body>
</html>
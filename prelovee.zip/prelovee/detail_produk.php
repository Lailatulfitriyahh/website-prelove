<?php
include 'koneksi.php'; // Hubungkan ke file koneksi database

// Pastikan parameter id_produk ada di URL
if (isset($_GET['id_produk'])) {
    $id_produk = mysqli_real_escape_string($koneksi, $_GET['id_produk']);

    // Query untuk mengambil detail produk berdasarkan ID
    $query = "SELECT * FROM produk WHERE id_produk = '$id_produk'";
    $result = mysqli_query($koneksi, $query);

    // Cek apakah produk ditemukan
    if (mysqli_num_rows($result) > 0) {
        $produk = mysqli_fetch_assoc($result);
    } else {
        // Jika produk tidak ditemukan, arahkan ke halaman 404 atau daftar produk
        header("Location: produk.php"); // Atau halaman produk.php jika ada
        exit();
    }
} else {
    // Jika tidak ada id_produk di URL, arahkan ke halaman daftar produk
    header("Location: produk.php"); // Atau halaman produk.php jika ada
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Detail Produk - Thriftpreelove</title>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
    <style>
      /* ... (Kode CSS Anda yang sudah ada) ... */

      /* Gaya dasar */
      body {
        font-family: sans-serif;
        margin: 0;
        background-color: #f9f9f9;
      }

      /* Navbar Styling - Consistent with other pages */
      .navbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          background-color: black;
          color: white;
          padding: 10px 20px;
          position: fixed;
          width: 100%;
          top: 0;
          left: 0;
          z-index: 1000;
      }

      .navbar .logo a {
          color: white;
          font-size: 20px;
          font-weight: bold;
          text-decoration: none;
      }

      .nav-links {
          display: flex;
          gap: 20px;
          list-style: none;
          margin: 0 auto;
          flex-grow: 1;
          justify-content: center;
      }

      .nav-links li a {
          color: white;
          text-decoration: none;
          font-weight: bold;
      }

      .search-container-inline {
          display: flex;
          align-items: center;
          margin-right: 20px;
      }

      .search-container-inline input[type="text"] {
          padding: 8px 15px;
          border: none;
          border-radius: 20px 0 0 20px;
          outline: none;
          width: 220px;
          background-color: white;
          color: #333;
          font-size: 16px;
      }

      .search-container-inline button {
          background-color: #e0b0ff;
          border: none;
          padding: 8px 15px;
          border-radius: 0 20px 20px 0;
          margin-left: -1px;
          cursor: pointer;
          color: black;
          transition: background-color 0.3s ease;
          font-size: 16px;
      }

      .search-container-inline button:hover {
          background-color: #cc99ff;
      }

      .nav-icons {
        display: flex;
        align-items: center;
        gap: 15px;
      }

      .nav-icons a {
        color: white;
        font-size: 18px;
        text-decoration: none;
        transition: color 0.3s ease;
      }

      .nav-icons a:hover {
        color: #e0b0ff;
      }

      .auth-links {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-left: 15px;
      }

      .auth-links a {
          background-color: #4a4a4a;
          padding: 8px 15px;
          border-radius: 8px;
          color: white;
          text-decoration: none;
          font-weight: bold;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-width: 80px;
          transition: background-color 0.3s ease, transform 0.1s ease;
      }

      .auth-links a:hover {
          background-color: #666;
          transform: translateY(-1px);
      }

      /* Gaya khusus untuk halaman detail produk */
      .detail-section {
          padding: 80px 20px; /* Sesuaikan padding-top dengan tinggi navbar */
          text-align: center;
          max-width: 800px;
          margin: 20px auto;
          background-color: white;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      }

      .detail-section img {
          max-width: 100%;
          height: auto;
          border-radius: 8px;
          margin-bottom: 20px;
      }

      .detail-section h1 {
          font-size: 2.5em;
          margin-bottom: 10px;
          color: #333;
      }

      .detail-section .price {
          font-size: 1.8em;
          font-weight: bold;
          color: #e0b0ff;
          margin-bottom: 20px;
      }

      .detail-section .description {
          font-size: 1.1em;
          line-height: 1.8;
          color: #555;
          margin-bottom: 30px;
          text-align: left;
      }

      .cta-button {
          background-color: #e0b0ff;
          border: none;
          padding: 10px 20px;
          border-radius: 20px;
          font-weight: bold;
          cursor: pointer;
          margin-top: 10px;
          display: inline-block;
          text-decoration: none;
          color: black;
      }

      footer {
          background-color: #222;
          color: white;
          text-align: center;
          padding: 15px;
          margin-top: 20px;
      }
    </style>
  </head>
  <body>
    <header>
      <nav class="navbar">
        <div class="logo">
          <a href="index.html#home">thriftpreelove.</a>
        </div>
        <ul class="nav-links">
          <li><a href="index.html#home">Home</a></li>
          <li><a href="index.html#tentang-kami">Tentang Kami</a></li>
          <li><a href="produk.php">Produk</a></li>
          <li><a href="index.html#kontak">Kontak</a></li>
        </ul>

        <div class="search-container-inline">
          <form action="search.php" method="GET" style="display: flex;">
              <input type="text" name="query" placeholder="Cari produk...">
              <button type="submit"><i class="fas fa-search"></i></button>
          </form>
        </div>

        <div style="display: flex; align-items: center">
          <div class="nav-icons">
            <a href="cart.php" class="cart-icon" title="Lihat Keranjang">
              <i class="fas fa-shopping-cart"></i>
            </a>
          </div>

          <div class="auth-links">
            <a href="profile.php">Profil</a>
            <a href="logout.php">Logout</a>
          </div>
        </div>
      </nav>
    </header>

    <main>
      <section class="detail-section">
        <?php if (isset($produk)): // Pastikan data produk ada ?>
        <img src="img/<?php echo htmlspecialchars($produk['gambar_produk']); ?>" alt="<?php echo htmlspecialchars($produk['nama_produk']); ?>" />
        <h1><?php echo htmlspecialchars($produk['nama_produk']); ?></h1>
        <p class="price">Rp <?php echo number_format($produk['harga'], 0, ',', '.'); ?></p>
        <p class="description"><?php echo nl2br(htmlspecialchars($produk['deskripsi_produk'])); ?></p>

        <form action="cart.php" method="POST" style="display: inline-block;">
            <input type="hidden" name="action" value="add">
            <input type="hidden" name="id_produk" value="<?php echo htmlspecialchars($produk['id_produk']); ?>">
            <button type="submit" class="cta-button">Tambah ke Keranjang</button>
        </form>

        <a href="produk.php" class="cta-button" style="background-color: #555; margin-left: 10px; color: white;">Kembali ke Produk</a>
        <?php else: ?>
        <p>Produk tidak ditemukan.</p>
        <a href="produk.php" class="cta-button">Lihat Produk Lainnya</a>
        <?php endif; ?>
      </section>
    </main>

    <footer>
      <div class="container">
        <p>&copy; 2025 Thriftpreelove. Semua Hak Dilindungi.</p>
      </div>
    </footer>
  </body>
</html>
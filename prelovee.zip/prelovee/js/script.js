document.addEventListener("DOMContentLoaded", () => {
  // Fungsi untuk memperbarui tampilan tautan otentikasi di navbar
  function updateAuthLinks() {
    const authLinksContainer = document.querySelector(".auth-links");

    // Buat permintaan ke server PHP untuk mendapatkan status login
    fetch("check_login_status.php")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok " + response.statusText);
        }
        return response.json(); // Menguraikan respons JSON
      })
      .then((data) => {
        if (data.loggedIn) {
          // Jika pengguna login, tampilkan profil dan logout
          authLinksContainer.innerHTML = `
                        <a href="profile.php" class="profile-button">
                            <i class="fas fa-user"></i>
                            ${data.username}
                        </a>
                        <a href="logout.php">Logout</a>
                    `;
          // Tambahkan event listener untuk logout jika Anda ingin penanganan klien-saja (tidak disarankan untuk logout sebenarnya)
          // document.querySelector('.auth-links a[href="logout.php"]').addEventListener('click', (e) => {
          //     e.preventDefault();
          //     // Logika logout AJAX di sini, lalu panggil updateAuthLinks() lagi
          //     fetch('logout.php').then(() => {
          //         updateAuthLinks();
          //         alert('Anda telah logout.');
          //         window.location.href = 'index.html'; // Redirect ke home atau halaman lain
          //     });
          // });
        } else {
          // Jika pengguna tidak login, tampilkan login dan daftar
          authLinksContainer.innerHTML = `
                        <a href="login.php" id="loginLink">Login</a>
                        <a href="register.php" id="registerLink">Daftar</a>
                    `;
        }
      })
      .catch((error) => {
        console.error("Ada masalah dengan operasi fetch:", error);
        // Fallback jika ada error (tampilkan link login/daftar secara default)
        authLinksContainer.innerHTML = `
                    <a href="login.php" id="loginLink">Login</a>
                    <a href="register.php" id="registerLink">Daftar</a>
                `;
      });
  }

  // Panggil fungsi ini saat halaman dimuat
  updateAuthLinks();

  // Opsional: Panggil updateAuthLinks() lagi setelah login/logout berhasil dari halaman login/register
  // Ini membutuhkan sedikit penyesuaian di login.php dan register.php
  // Misalnya, setelah login berhasil, login.php bisa mengarahkan ke index.html?login_success=true
  // Dan di sini Anda bisa memeriksa parameter URL:
  // const urlParams = new URLSearchParams(window.location.search);
  // if (urlParams.get('login_success') === 'true') {
  //     updateAuthLinks();
  // }

  // ************* Kode untuk Smooth Scrolling (sudah ada) *************
  // Gunakan ini jika Anda ingin memastikan dukungan smooth scrolling di browser lama
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      const targetId = this.getAttribute("href");
      if (targetId.startsWith("#") && targetId.length > 1) {
        e.preventDefault();

        const targetElement = document.querySelector(targetId);

        if (targetElement) {
          const navbarHeight = document.querySelector(".navbar").offsetHeight;
          const targetPosition =
            targetElement.getBoundingClientRect().top +
            window.scrollY -
            navbarHeight;

          window.scrollTo({
            top: targetPosition,
            behavior: "smooth",
          });
        }
      }
    });
  });

  // *******************************************************************
});

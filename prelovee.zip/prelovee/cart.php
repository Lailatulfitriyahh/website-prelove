<?php
session_start(); // Selalu mulai session di awal file untuk menggunakan $_SESSION
include 'koneksi.php'; // Hubungkan ke file koneksi database Anda

// Pastikan keranjang diinisialisasi jika belum ada di session
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = []; // Keranjang berupa array kosong
}

$message = ""; // Untuk pesan notifikasi kepada pengguna

// --- Logika Penanganan Aksi Keranjang ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? ''; // Ambil aksi dari form (add, update_qty, remove)

    if ($action === 'add') {
        $id_produk = $_POST['id_produk'] ?? null;
        $quantity = (int)($_POST['quantity'] ?? 1); // Default quantity 1

        if ($id_produk) {
            // Ambil detail produk dari database
            $query_produk = "SELECT id_produk, nama_produk, harga, gambar_produk FROM produk WHERE id_produk = '$id_produk'";
            $result = mysqli_query($koneksi, $query_produk);

            if ($result && mysqli_num_rows($result) > 0) {
                $produk_detail = mysqli_fetch_assoc($result);

                // Cek apakah produk sudah ada di keranjang
                if (array_key_exists($id_produk, $_SESSION['cart'])) {
                    // Jika sudah ada, tambahkan kuantitasnya
                    $_SESSION['cart'][$id_produk]['quantity'] += $quantity;
                    $message = "Kuantitas '<strong>" . htmlspecialchars($produk_detail['nama_produk']) . "</strong>' berhasil diperbarui.";
                } else {
                    // Jika belum ada, tambahkan produk baru ke keranjang
                    $_SESSION['cart'][$id_produk] = [
                        'id_produk' => $produk_detail['id_produk'],
                        'nama_produk' => $produk_detail['nama_produk'],
                        'harga' => $produk_detail['harga'],
                        'gambar_produk' => $produk_detail['gambar_produk'],
                        'quantity' => $quantity
                    ];
                    $message = "Produk '<strong>" . htmlspecialchars($produk_detail['nama_produk']) . "</strong>' berhasil ditambahkan ke keranjang.";
                }
            } else {
                $message = "Produk tidak ditemukan.";
            }
        } else {
            $message = "ID Produk tidak valid.";
        }
    } elseif ($action === 'update_qty') {
        $id_produk = $_POST['id_produk'] ?? null;
        $new_quantity = (int)($_POST['quantity'] ?? 0);

        if ($id_produk && array_key_exists($id_produk, $_SESSION['cart'])) {
            if ($new_quantity > 0) {
                $_SESSION['cart'][$id_produk]['quantity'] = $new_quantity;
                $message = "Kuantitas berhasil diperbarui.";
            } else {
                // Jika kuantitas 0 atau kurang, hapus produk dari keranjang
                unset($_SESSION['cart'][$id_produk]);
                $message = "Produk dihapus dari keranjang.";
            }
        } else {
            $message = "Produk tidak ditemukan di keranjang.";
        }
    } elseif ($action === 'remove') {
        $id_produk = $_POST['id_produk'] ?? null;
        if ($id_produk && array_key_exists($id_produk, $_SESSION['cart'])) {
            unset($_SESSION['cart'][$id_produk]);
            $message = "Produk berhasil dihapus dari keranjang.";
        } else {
            $message = "Produk tidak ditemukan di keranjang.";
        }
    }
    // Redirect POST to GET to prevent form resubmission on refresh
    header('Location: cart.php?status=' . urlencode($message));
    exit();
}

// Ambil pesan status dari URL jika ada (setelah redirect POST)
if (isset($_GET['status'])) {
    $message = htmlspecialchars($_GET['status']);
}

// Tutup koneksi database
if (isset($koneksi)) {
    mysqli_close($koneksi);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Keranjang Belanja - Thriftpreelove</title>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
    <style>
        /* Gaya dasar */
        body {
            font-family: sans-serif;
            margin: 0;
            background-color: #f9f9f9;
        }

        /* Navbar Styling - Consistent with other pages */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: black;
            color: white;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .navbar .logo a {
            color: white;
            font-size: 20px;
            font-weight: bold;
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0 auto;
            flex-grow: 1;
            justify-content: center;
        }

        .nav-links li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .search-container-inline {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }

        .search-container-inline input[type="text"] {
            padding: 8px 15px;
            border: none;
            border-radius: 20px 0 0 20px;
            outline: none;
            width: 220px;
            background-color: white;
            color: #333;
            font-size: 16px;
        }

        .search-container-inline button {
            background-color: #e0b0ff;
            border: none;
            padding: 8px 15px;
            border-radius: 0 20px 20px 0;
            margin-left: -1px;
            cursor: pointer;
            color: black;
            transition: background-color 0.3s ease;
            font-size: 16px;
        }

        .search-container-inline button:hover {
            background-color: #cc99ff;
        }

        .nav-icons {
          display: flex;
          align-items: center;
          gap: 15px;
        }

        .nav-icons a {
          color: white;
          font-size: 18px;
          text-decoration: none;
          transition: color 0.3s ease;
        }

        .nav-icons a:hover {
          color: #e0b0ff;
        }

        .auth-links {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-left: 15px;
        }

        .auth-links a {
            background-color: #4a4a4a;
            padding: 8px 15px;
            border-radius: 8px;
            color: white;
            text-decoration: none;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 80px;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }

        .auth-links a:hover {
            background-color: #666;
            transform: translateY(-1px);
        }

        /* Gaya Khusus Halaman Keranjang */
        .cart-section {
            padding: 80px 20px; /* Sesuaikan padding-top dengan tinggi navbar */
            text-align: center;
            max-width: 900px;
            margin: 20px auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .cart-section h2 {
            font-size: 2.5em;
            margin-bottom: 20px;
            color: #333;
        }

        .cart-section .message {
            background-color: #e0b0ff;
            color: black;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            display: <?php echo empty($message) ? 'none' : 'block'; ?>; /* Sembunyikan jika tidak ada pesan */
        }

        .cart-items {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .cart-items th, .cart-items td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: left;
            vertical-align: middle;
        }

        .cart-items th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .cart-items img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
            margin-right: 10px;
            vertical-align: middle;
        }

        .cart-items .item-info {
            display: flex;
            align-items: center;
        }

        .cart-items .item-info .name {
            font-weight: bold;
            color: #333;
        }

        .cart-items .item-quantity input[type="number"] {
            width: 60px;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            text-align: center;
            -moz-appearance: textfield; /* Untuk Firefox */
        }
        .cart-items .item-quantity input[type="number"]::-webkit-outer-spin-button,
        .cart-items .item-quantity input[type="number"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .cart-items .item-total {
            font-weight: bold;
            color: #e0b0ff;
        }

        .cart-items .action-buttons form {
            display: inline-block;
            margin-right: 5px;
        }

        .cart-items .remove-button {
            background-color: #ff6b6b;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .cart-items .remove-button:hover {
            background-color: #e65c5c;
        }

        .cart-items .update-qty-button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .cart-items .update-qty-button:hover {
            background-color: #45a049;
        }

        .cart-summary {
            text-align: right;
            margin-top: 20px;
            border-top: 2px solid #eee;
            padding-top: 20px;
        }

        .cart-summary .total-price {
            font-size: 1.8em;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
        }

        .checkout-button {
            background-color: #e0b0ff;
            border: none;
            padding: 12px 25px;
            border-radius: 25px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            color: black;
            font-size: 1.1em;
            transition: background-color 0.3s ease;
        }

        .checkout-button:hover {
            background-color: #cc99ff;
        }

        .continue-shopping-button {
            background-color: #555;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 25px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 1.1em;
            transition: background-color 0.3s ease;
            margin-right: 10px;
        }

        .continue-shopping-button:hover {
            background-color: #777;
        }

        /* Footer */
        footer {
            background-color: #222;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 40px;
        }
    </style>
</head>
<body>

    <header>
        <nav class="navbar">
            <div class="logo">
                <a href="index.html#home">thriftpreelove.</a>
            </div>
            <ul class="nav-links">
                <li><a href="index.html#home">Home</a></li>
                <li><a href="index.html#tentang-kami">Tentang Kami</a></li>
                <li><a href="produk.php">Produk</a></li>
                <li><a href="index.html#kontak">Kontak</a></li>
            </ul>

            <div class="search-container-inline">
                <form action="search.php" method="GET" style="display: flex;">
                    <input type="text" name="query" placeholder="Cari produk...">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>

            <div style="display: flex; align-items: center">
                <div class="nav-icons">
                    <a href="cart.php" class="cart-icon" title="Lihat Keranjang">
                        <i class="fas fa-shopping-cart"></i>
                    </a>
                </div>

                <div class="auth-links">
                    <a href="profile.php">Profil</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="cart-section">
            <h2>Keranjang Belanja Anda</h2>

            <?php if (!empty($message)): ?>
                <p class="message"><?php echo $message; ?></p>
            <?php endif; ?>

            <?php if (!empty($_SESSION['cart'])): ?>
            <table class="cart-items">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Total</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $grand_total = 0;
                    foreach ($_SESSION['cart'] as $id => $item):
                        $item_total = $item['harga'] * $item['quantity'];
                        $grand_total += $item_total;
                    ?>
                    <tr>
                        <td>
                            <div class="item-info">
                                <img src="img/<?php echo htmlspecialchars($item['gambar_produk']); ?>" alt="<?php echo htmlspecialchars($item['nama_produk']); ?>">
                                <span class="name"><?php echo htmlspecialchars($item['nama_produk']); ?></span>
                            </div>
                        </td>
                        <td>Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></td>
                        <td>
                            <form action="cart.php" method="POST" class="item-quantity">
                                <input type="hidden" name="action" value="update_qty">
                                <input type="hidden" name="id_produk" value="<?php echo htmlspecialchars($item['id_produk']); ?>">
                                <input type="number" name="quantity" value="<?php echo htmlspecialchars($item['quantity']); ?>" min="0" onchange="this.form.submit()">
                                </form>
                        </td>
                        <td class="item-total">Rp <?php echo number_format($item_total, 0, ',', '.'); ?></td>
                        <td class="action-buttons">
                            <form action="cart.php" method="POST">
                                <input type="hidden" name="action" value="remove">
                                <input type="hidden" name="id_produk" value="<?php echo htmlspecialchars($item['id_produk']); ?>">
                                <button type="submit" class="remove-button"><i class="fas fa-trash-alt"></i> Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="cart-summary">
                <div class="total-price">
                    Total Belanja: Rp <?php echo number_format($grand_total, 0, ',', '.'); ?>
                </div>
                <a href="produk.php" class="continue-shopping-button">Lanjutkan Belanja</a>
                <a href="checkout.php" class="checkout-button">Bayar Sekarang</a>
            </div>

            <?php else: ?>
                <p>Keranjang belanja Anda kosong. <a href="produk.php">Mulai belanja sekarang!</a></p>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Thriftpreelove. Semua Hak Dilindungi.</p>
        </div>
    </footer>
</body>
</html>
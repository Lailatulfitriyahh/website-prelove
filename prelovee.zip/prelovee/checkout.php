<?php
session_start();
include 'koneksi.php'; // Hubungkan ke file koneksi database

$message = "";
$error_fields = []; // Array untuk menandai field yang kosong

// Pastikan keranjang tidak kosong
if (empty($_SESSION['cart'])) {
    header('Location: cart.php?status=' . urlencode("Keranjang Anda kosong, tidak bisa melanjutkan checkout."));
    exit();
}

$cart_items = $_SESSION['cart'];
$grand_total = 0;
foreach ($cart_items as $item) {
    $grand_total += $item['harga'] * $item['quantity'];
}

// Inisialisasi variabel form (jika ada data dari percobaan sebelumnya)
$customer_name = $_POST['customer_name'] ?? '';
$customer_email = $_POST['customer_email'] ?? '';
$shipping_address = $_POST['shipping_address'] ?? '';
$phone_number = $_POST['phone_number'] ?? '';
$payment_method = $_POST['payment_method'] ?? '';

// --- Proses Checkout (Saat Form Disubmit) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    // Validasi input
    if (empty($customer_name)) { $error_fields['customer_name'] = true; }
    if (empty($shipping_address)) { $error_fields['shipping_address'] = true; }
    if (empty($phone_number)) { $error_fields['phone_number'] = true; }
    if (empty($payment_method)) { $error_fields['payment_method'] = true; }

    if (empty($error_fields)) {
        // Semua data valid, mulai proses penyimpanan pesanan ke database
        mysqli_begin_transaction($koneksi); // Mulai transaksi

        try {
            // 1. Masukkan data ke tabel 'orders'
            $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : NULL; // Ambil user_id jika user login
            $order_date = date('Y-m-d H:i:s'); // Waktu saat ini

            $stmt_order = mysqli_prepare($koneksi, "INSERT INTO orders (user_id, order_date, total_amount, customer_name, customer_email, shipping_address, phone_number, payment_method, order_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (!$stmt_order) {
                throw new Exception("Prepare statement order gagal: " . mysqli_error($koneksi));
            }
            mysqli_stmt_bind_param($stmt_order, "isdssssss", $user_id, $order_date, $grand_total, $customer_name, $customer_email, $shipping_address, $phone_number, $payment_method, $order_status_default);
            $order_status_default = 'Pending';
            if (!mysqli_stmt_execute($stmt_order)) {
                throw new Exception("Eksekusi statement order gagal: " . mysqli_stmt_error($stmt_order));
            }
            $order_id = mysqli_insert_id($koneksi); // Ambil ID pesanan yang baru saja dibuat
            mysqli_stmt_close($stmt_order);

            // 2. Masukkan item-item keranjang ke tabel 'order_items'
            $stmt_order_item = mysqli_prepare($koneksi, "INSERT INTO order_items (order_id, product_id, product_name, quantity, price_per_item) VALUES (?, ?, ?, ?, ?)");
            if (!$stmt_order_item) {
                throw new Exception("Prepare statement order item gagal: " . mysqli_error($koneksi));
            }

            foreach ($cart_items as $item) {
                mysqli_stmt_bind_param($stmt_order_item, "iisid", $order_id, $item['id_produk'], $item['nama_produk'], $item['quantity'], $item['harga']);
                if (!mysqli_stmt_execute($stmt_order_item)) {
                    throw new Exception("Eksekusi statement order item gagal: " . mysqli_stmt_error($stmt_order_item));
                }
            }
            mysqli_stmt_close($stmt_order_item);

            mysqli_commit($koneksi); // Commit transaksi jika semua berhasil
            $_SESSION['cart'] = []; // Kosongkan keranjang setelah pesanan berhasil
            $message = "Pesanan Anda berhasil ditempatkan! Nomor Pesanan Anda: " . $order_id;
            // Redirect ke halaman konfirmasi atau home
            header('Location: order_confirmation.php?order_id=' . $order_id); // Anda perlu membuat halaman ini
            exit();

        } catch (Exception $e) {
            mysqli_rollback($koneksi); // Rollback transaksi jika terjadi kesalahan
            $message = "Terjadi kesalahan saat memproses pesanan Anda: " . $e->getMessage();
        }
    } else {
        $message = "Harap lengkapi semua bidang yang wajib diisi.";
    }
}

// Tutup koneksi database
if (isset($koneksi)) {
    mysqli_close($koneksi);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Checkout - Thriftpreelove</title>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
    <style>
        /* Gaya dasar */
        body {
            font-family: sans-serif;
            margin: 0;
            background-color: #f9f9f9;
        }

        /* Navbar Styling - Consistent with other pages */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: black;
            color: white;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .navbar .logo a {
            color: white;
            font-size: 20px;
            font-weight: bold;
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0 auto;
            flex-grow: 1;
            justify-content: center;
        }

        .nav-links li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .search-container-inline {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }

        .search-container-inline input[type="text"] {
            padding: 8px 15px;
            border: none;
            border-radius: 20px 0 0 20px;
            outline: none;
            width: 220px;
            background-color: white;
            color: #333;
            font-size: 16px;
        }

        .search-container-inline button {
            background-color: #e0b0ff;
            border: none;
            padding: 8px 15px;
            border-radius: 0 20px 20px 0;
            margin-left: -1px;
            cursor: pointer;
            color: black;
            transition: background-color 0.3s ease;
            font-size: 16px;
        }

        .search-container-inline button:hover {
            background-color: #cc99ff;
        }

        .nav-icons {
          display: flex;
          align-items: center;
          gap: 15px;
        }

        .nav-icons a {
          color: white;
          font-size: 18px;
          text-decoration: none;
          transition: color 0.3s ease;
        }

        .nav-icons a:hover {
          color: #e0b0ff;
        }

        .auth-links {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-left: 15px;
        }

        .auth-links a {
            background-color: #4a4a4a;
            padding: 8px 15px;
            border-radius: 8px;
            color: white;
            text-decoration: none;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 80px;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }

        .auth-links a:hover {
            background-color: #666;
            transform: translateY(-1px);
        }

        /* Gaya Khusus Halaman Checkout */
        .checkout-section {
            padding: 80px 20px;
            text-align: left;
            max-width: 900px;
            margin: 20px auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .checkout-section h2 {
            font-size: 2.5em;
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }

        .checkout-section .message {
            background-color: #ffe0b0; /* Light orange for warnings/errors */
            color: #d35400; /* Darker orange text */
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }
        .checkout-section .message.success {
            background-color: #d4edda; /* Light green for success */
            color: #155724; /* Dark green text */
        }


        .checkout-container {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            padding: 20px;
        }

        .checkout-form, .order-summary {
            flex: 1;
            min-width: 300px;
        }

        .checkout-form h3, .order-summary h3 {
            font-size: 1.8em;
            color: #333;
            margin-bottom: 20px;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group textarea,
        .form-group select {
            width: calc(100% - 22px); /* Adjust for padding and border */
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
            box-sizing: border-box; /* Include padding and border in the element's total width and height */
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        .form-group .error-border {
            border: 1px solid red;
        }

        .payment-options {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .payment-options label {
            background-color: #f2f2f2;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            display: flex;
            align-items: center;
        }

        .payment-options label:hover {
            background-color: #eaeaea;
        }

        .payment-options input[type="radio"] {
            margin-right: 10px;
        }

        .order-summary table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .order-summary th, .order-summary td {
            padding: 10px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        .order-summary th {
            background-color: #f8f8f8;
        }

        .order-summary .summary-total {
            text-align: right;
            font-size: 1.5em;
            font-weight: bold;
            padding-top: 15px;
            border-top: 2px solid #eee;
        }

        .place-order-button {
            background-color: #e0b0ff;
            border: none;
            padding: 12px 25px;
            border-radius: 25px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            color: black;
            font-size: 1.1em;
            transition: background-color 0.3s ease;
            width: 100%;
            margin-top: 20px;
        }

        .place-order-button:hover {
            background-color: #cc99ff;
        }

        /* Footer */
        footer {
            background-color: #222;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 40px;
        }
    </style>
</head>
<body>

    <header>
        <nav class="navbar">
            <div class="logo">
                <a href="index.html#home">thriftpreelove.</a>
            </div>
            <ul class="nav-links">
                <li><a href="index.html#home">Home</a></li>
                <li><a href="index.html#tentang-kami">Tentang Kami</a></li>
                <li><a href="produk.php">Produk</a></li>
                <li><a href="index.html#kontak">Kontak</a></li>
            </ul>

            <div class="search-container-inline">
                <form action="search.php" method="GET" style="display: flex;">
                    <input type="text" name="query" placeholder="Cari produk...">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>

            <div style="display: flex; align-items: center">
                <div class="nav-icons">
                    <a href="cart.php" class="cart-icon" title="Lihat Keranjang">
                        <i class="fas fa-shopping-cart"></i>
                    </a>
                </div>

                <div class="auth-links">
                    <a href="profile.php">Profil</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="checkout-section">
            <h2>Detail Checkout</h2>

            <?php if (!empty($message)): ?>
                <p class="message <?php echo strpos($message, 'berhasil') !== false ? 'success' : ''; ?>"><?php echo $message; ?></p>
            <?php endif; ?>

            <div class="checkout-container">
                <div class="checkout-form">
                    <h3>Informasi Pengiriman</h3>
                    <form action="checkout.php" method="POST">
                        <div class="form-group">
                            <label for="customer_name">Nama Lengkap <span style="color: red;">*</span></label>
                            <input type="text" id="customer_name" name="customer_name" value="<?php echo htmlspecialchars($customer_name); ?>" required class="<?php echo isset($error_fields['customer_name']) ? 'error-border' : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label for="customer_email">Email</label>
                            <input type="email" id="customer_email" name="customer_email" value="<?php echo htmlspecialchars($customer_email); ?>">
                        </div>
                        <div class="form-group">
                            <label for="phone_number">Nomor Telepon <span style="color: red;">*</span></label>
                            <input type="text" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($phone_number); ?>" required class="<?php echo isset($error_fields['phone_number']) ? 'error-border' : ''; ?>">
                        </div>
                        <div class="form-group">
                            <label for="shipping_address">Alamat Pengiriman <span style="color: red;">*</span></label>
                            <textarea id="shipping_address" name="shipping_address" required class="<?php echo isset($error_fields['shipping_address']) ? 'error-border' : ''; ?>"><?php echo htmlspecialchars($shipping_address); ?></textarea>
                        </div>

                        <h3>Metode Pembayaran</h3>
                        <div class="form-group payment-options">
                            <label>
                                <input type="radio" name="payment_method" value="Bank Transfer" <?php echo ($payment_method == 'Bank Transfer') ? 'checked' : ''; ?> required>
                                Transfer Bank (BCA, Mandiri, dll.)
                            </label>
                            <label>
                                <input type="radio" name="payment_method" value="COD" <?php echo ($payment_method == 'COD') ? 'checked' : ''; ?>>
                                Bayar di Tempat (Cash on Delivery)
                            </label>
                            <label>
                                <input type="radio" name="payment_method" value="E-Wallet" <?php echo ($payment_method == 'E-Wallet') ? 'checked' : ''; ?>>
                                E-Wallet (OVO, GoPay, Dana)
                            </label>
                            <?php if (isset($error_fields['payment_method'])): ?>
                                <p style="color: red; font-size: 0.9em; margin-top: 5px;">Pilih metode pembayaran.</p>
                            <?php endif; ?>
                        </div>

                        <button type="submit" name="place_order" class="place-order-button">Selesaikan Pesanan</button>
                    </form>
                </div>

                <div class="order-summary">
                    <h3>Ringkasan Pesanan</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Qty</th>
                                <th>Harga</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cart_items as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['nama_produk']); ?></td>
                                <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                                <td>Rp <?php echo number_format($item['harga'], 0, ',', '.'); ?></td>
                                <td>Rp <?php echo number_format($item['harga'] * $item['quantity'], 0, ',', '.'); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="summary-total">
                        Total: Rp <?php echo number_format($grand_total, 0, ',', '.'); ?>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Thriftpreelove. Semua Hak Dilindungi.</p>
        </div>
    </footer>
    <?php
// ... (Kode PHP yang sudah ada di bagian atas file checkout.php Anda) ...

// --- Proses Checkout (Saat Form Disubmit) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    // ... (Validasi input yang sudah ada) ...

    if (empty($error_fields)) {
        // ... (Kode penyimpanan pesanan ke database yang sudah ada) ...

        try {
            // ... (Bagian insert ke tabel 'orders' dan 'order_items' yang sudah ada) ...

            mysqli_commit($koneksi); // Commit transaksi jika semua berhasil
            $_SESSION['cart'] = []; // Kosongkan keranjang setelah pesanan berhasil
            $message = "Pesanan Anda berhasil ditempatkan! Nomor Pesanan Anda: " . $order_id;

            // --- BAGIAN BARU: KIRIM NOTIFIKASI WHATSAPP ---
            // Ganti nilai-nilai di bawah ini dengan data Anda
            $whatsapp_target_number = '6281234567890'; // <-- GANTI dengan NOMOR WHATSAPP Anda (contoh: 62812xxxxxx)
                                                    // Format internasional tanpa tanda +
            $whatsapp_api_key = '072c09b23f17319cc64a264c74e9090831729116'; // <-- GANTI dengan API KEY dari penyedia layanan WhatsApp Anda
            $whatsapp_api_url = 'https://api.watsap.id/send-message'; // <-- GANTI dengan URL API dari penyedia layanan Anda

            // Format pesan yang akan dikirim ke WhatsApp Anda
            $order_details_message = "🔔 *PESANAN BARU!* 🔔\n\n";
            $order_details_message .= "Nomor Pesanan: #{$order_id}\n";
            $order_details_message .= "Tanggal: " . date('d M Y H:i', strtotime($order_date)) . "\n\n";
            $order_details_message .= "*Info Pelanggan:*\n";
            $order_details_message .= "Nama: {$customer_name}\n";
            if (!empty($customer_email)) {
                $order_details_message .= "Email: {$customer_email}\n";
            }
            $order_details_message .= "Telepon: {$phone_number}\n";
            $order_details_message .= "Alamat: {$shipping_address}\n";
            $order_details_message .= "Metode Pembayaran: {$payment_method}\n\n";
            $order_details_message .= "*Detail Pesanan:*\n";
            foreach ($cart_items as $item) {
                $order_details_message .= "- " . htmlspecialchars($item['nama_produk']) . " (x" . htmlspecialchars($item['quantity']) . ") - Rp " . number_format($item['harga'], 0, ',', '.') . "\n";
            }
            $order_details_message .= "\n*TOTAL: Rp " . number_format($grand_total, 0, ',', '.') . "*\n\n";
            $order_details_message .= "Segera cek dashboard untuk memproses pesanan ini ya!";

            // Mengirim pesan menggunakan cURL
           $curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_HEADER, 0);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($curl, CURLOPT_MAXREDIRS, 10);
curl_setopt($curl, CURLOPT_TIMEOUT, 0); // batas waktu response
curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($curl, CURLOPT_POST, 1);
                // Sesuaikan format body ini dengan dokumentasi API penyedia Anda!
                curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data_post));
              curl_setopt($curl, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
     

           $response = curl_exec($curl);
curl_close($curl);
echo $response;

            if ($err) {
                // Ini akan mencatat error ke log server Anda jika pengiriman WhatsApp gagal
                error_log("WhatsApp Notification cURL Error #:" . $err);
            } else {
                // Opsional: Anda bisa mem-parsing $response untuk melihat status pengiriman dari API
                // error_log("WhatsApp Response: " . $response);
            }
            // --- AKHIR BAGIAN BARU ---

            // Redirect ke halaman konfirmasi atau home (tetap ada di bagian akhir try)
            header('Location: order_confirmation.php?order_id=' . $order_id);
            exit();

        } catch (Exception $e) {
            mysqli_rollback($koneksi); // Rollback transaksi jika terjadi kesalahan
            $message = "Terjadi kesalahan saat memproses pesanan Anda: " . $e->getMessage();
        }
    } else {
        $message = "Harap lengkapi semua bidang yang wajib diisi.";
    }
}
// ... (Kode PHP yang sudah ada di bagian bawah file checkout.php Anda) ...
?>
</body>
</html>
<?php
session_start();
// Sertakan file koneksi database Anda di sini jika Anda berencana mengambil data produk dinamis
// Hapus komentar baris di bawah ini jika Anda ingin produk di bagian 'Produk Kami' tampil dinamis
// include 'koneksi.php';

// Jika Anda ingin menampilkan produk dinamis di bagian 'Produk Kami' pada index.php,
// Anda perlu menjalankan query database di sini setelah include 'koneksi.php';
// Contoh:
// $query_produk_beranda = "SELECT id_produk, nama_produk, harga, gambar_produk FROM produk ORDER BY id_produk ASC LIMIT 6"; // Menampilkan 6 produk pertama
// $result_produk_beranda = null; // Inisialisasi untuk menghindari error jika koneksi tidak diaktifkan

// if (isset($koneksi)) { // Pastikan koneksi sudah ada sebelum query
//     $result_produk_beranda = mysqli_query($koneksi, $query_produk_beranda);
//     if (!$result_produk_beranda) {
//         die("Query produk beranda gagal: " . mysqli_error($koneksi));
//     }
// }
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Thriftpreelove - Mari Mencari Baju Thrift dan Prelove</title>
  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
  <style>
    /* Styling Anda yang sudah ada */
    body {
      font-family: sans-serif;
      margin: 0;
      background-color: #f9f9f9;
    }

    .navbar {
      display: flex;
      /* Mengubah justify-content untuk menengahkan elemen */
      justify-content: space-between; /* Tetap space-between untuk menyebar item */
      align-items: center;
      background-color: black;
      color: white;
      padding: 10px 20px;
      position: fixed;
      width: 100%;
      top: 0;
      left: 0;
      z-index: 1000;
    }

    .navbar .logo a {
      color: white;
      font-size: 20px;
      font-weight: bold;
      text-decoration: none;
    }

    /* Modifikasi nav-links untuk menengahkan */
    .nav-links {
      display: flex;
      gap: 20px;
      list-style: none;
      /* Tambahkan margin auto di kedua sisi untuk menengahkan diri dalam flex container */
      margin: 0 auto;
      /* Jika navbar memiliki banyak item, ini akan mendorongnya ke tengah */
      flex-grow: 1; /* Biarkan nav-links tumbuh agar bisa mendorong search bar */
      justify-content: center; /* Pusat tautan di dalam nav-links itu sendiri */
    }

    .nav-links li a {
      color: white;
      text-decoration: none;
      font-weight: bold;
    }

    /* Gaya untuk bilah pencarian yang selalu terlihat */
    .search-container-inline {
      display: flex;
      align-items: center;
      /* Hapus margin-left: auto; karena nav-links sudah flex-grow */
      /* margin-left: auto; */
      margin-right: 20px;
    }

    .search-container-inline input[type="text"] {
      padding: 8px 15px;
      border: none;
      border-radius: 20px 0 0 20px;
      outline: none;
      width: 220px;
      background-color: white;
      color: #333;
      font-size: 16px;
    }

    .search-container-inline button {
      background-color: #e0b0ff;
      border: none;
      padding: 8px 15px;
      border-radius: 0 20px 20px 0;
      margin-left: -1px;
      cursor: pointer;
      color: black;
      transition: background-color 0.3s ease;
      font-size: 16px;
    }

    .search-container-inline button:hover {
      background-color: #cc99ff;
    }

    /* Gaya untuk ikon navigasi (keranjang) */
    .nav-icons {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .nav-icons a {
      color: white;
      font-size: 18px;
      text-decoration: none;
      transition: color 0.3s ease;
    }

    .nav-icons a:hover {
      color: #e0b0ff;
    }

    /* Styling tombol profil dan auth-links */
    .profile-button {
      background-color: #e0b0ff;
      padding: 6px 12px;
      border-radius: 20px;
      color: black !important;
      text-decoration: none;
      font-weight: bold;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      transition: background-color 0.3s ease;
    }

    .profile-button:hover {
      background-color: #cc99ff;
    }

    .auth-links {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-left: 15px;
    }

    .auth-links a {
      text-decoration: none;
      font-weight: bold;
      color: white;
      transition: color 0.3s ease;
    }

    .auth-links a:hover {
      color: #ddd;
    }

    /* Gaya yang sudah ada */
    .hero-section {
      padding-top: 60px;
      background-image: url("img/awalan.jpg");
      background-size: cover;
      background-position: center;
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      text-align: center;
      position: relative;
      box-shadow: inset 0 0 100px rgba(0, 0, 0, 0.7);
    }

    .hero-background::after {
      content: "";
      position: absolute;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      background: linear-gradient(
        to bottom,
        rgba(0, 0, 0, 0.5) 0%,
        rgba(0, 0, 0, 0.3) 40%,
        rgba(0, 0, 0, 0.2) 70%,
        rgba(247, 245, 245, 0) 100%
      );
      z-index: 1;
    }

    .hero-content {
      z-index: 2;
      max-width: 800px;
      padding: 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      width: 100%;
    }

    .hero-content h1 {
      font-size: 36px;
      margin-bottom: 10px;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
      max-width: 90%;
    }

    .hero-content p {
      font-size: 18px;
      margin-bottom: 20px;
      text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.6);
      max-width: 90%;
    }

    .cta-button {
      background-color: #e0b0ff;
      border: none;
      padding: 10px 20px;
      border-radius: 20px;
      font-weight: bold;
      cursor: pointer;
      margin-top: 10px;
      display: inline-block;
      text-decoration: none;
      color: black;
    }

    .about-us-section,
    .products-section,
    .contact-section {
      padding: 40px 20px;
      text-align: center;
    }

    .product-grid {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
      margin-top: 20px;
    }

    .product-item {
      background: white;
      padding: 15px;
      border-radius: 8px;
      width: 220px;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
    }

    .product-item img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      border-radius: 6px;
    }

    footer {
      background-color: #222;
      color: white;
      text-align: center;
      padding: 15px;
    }
  </style>
</head>
<body>

  <header>
    <nav class="navbar">
      <div class="logo">
        <a href="#home">thriftpreelove.</a>
      </div>
      <ul class="nav-links">
          <li><a href="#home">Home</a></li>
          <li><a href="#tentang-kami">Tentang Kami</a></li>
          <li><a href="#produk">Produk</a></li>
          <li><a href="#kontak">Kontak</a></li>
        </ul>

      <div class="search-container-inline">
        <form action="search.php" method="GET" style="display: flex;">
            <input type="text" name="query" placeholder="Cari produk...">
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>
      </div>

      <div style="display: flex; align-items: center">
        <div class="nav-icons">
          <a href="cart.php" class="cart-icon" title="Lihat Keranjang">
            <i class="fas fa-shopping-cart"></i>
          </a>
        </div>

        <div class="auth-links">
          <a href="login.php">Login</a>
          <a href="register.php">Daftar</a>
        </div>
      </div>
    </nav>
  </header>

  <main>
    <section id="home" class="hero-section">
      <div class="hero-content">
        <h1>Mari Mencari Baju Thrift dan Prelove</h1>
        <p>
          Temukan gaya unik dan berkualitas dari koleksi thrift pilihan kami.
        </p>
        <button class="cta-button">Beli Sekarang</button>
      </div>
      <div class="hero-background"></div>
    </section>

    <section id="tentang-kami" class="about-us-section">
      <div class="container">
        <h2>Tentang Kami</h2>
        <img src="img/toko.jpg" alt="Tentang Kami" width="180" height="180" />
        <p>
          Selamat datang di Thriftpreelove, tempat terbaik untuk fashion bekas
          berkualitas. Kami percaya setiap pakaian punya cerita, dan kami siap
          mempertemukannya dengan pemilik baru.
        </p>
        <p>
          Kami berdiri sejak 2023 dan terus berkomitmen pada keberlanjutan
          lingkungan dan gaya hidup hemat.
        </p>
        <p class="section-end-text">
          Setelah Anda mengenal kami lebih dekat, kini saatnya menjelajahi
          produk-produk pilihan yang telah kami siapkan khusus untuk Anda.
          Temukan harta karun mode Anda berikutnya!
        </p>
      </div>
    </section>

    <section id="produk" class="products-section">
      <div class="container">
        <h2>Produk Kami</h2>
        <p>Jelajahi koleksi terbaru kami!</p>
        <div class="product-grid">
          <?php
          // Uncomment dan aktifkan bagian ini jika Anda ingin produk di beranda diambil secara dinamis dari database
          /*
          if (isset($result_produk_beranda) && mysqli_num_rows($result_produk_beranda) > 0) {
              while($row = mysqli_fetch_assoc($result_produk_beranda)) {
          ?>
            <div class="product-item">
              <img src="img/<?php echo htmlspecialchars($row['gambar_produk']); ?>" alt="<?php echo htmlspecialchars($row['nama_produk']); ?>" />
              <h3><?php echo htmlspecialchars($row['nama_produk']); ?></h3>
              <p>Rp <?php echo number_format($row['harga'], 0, ',', '.'); ?></p>
              <a href="detail_produk.php?id_produk=<?php echo htmlspecialchars($row['id_produk']); ?>" class="cta-button">Lihat Detail</a>
            </div>
          <?php
              }
          } else if (isset($koneksi)) { // Pesan jika koneksi aktif tapi tidak ada produk
              echo "<p>Belum ada produk dinamis yang tersedia untuk ditampilkan di beranda.</p>";
          } else { // Pesan jika koneksi database tidak diaktifkan
              echo "<p>Produk dinamis dapat ditampilkan jika koneksi database diaktifkan.</p>";
          }
          */
          ?>
          <div class="product-item">
            <img src="img/kemeja.jpg" alt="Kemeja Kotak-kotak" />
            <h3>Kemeja Kotak-kotak</h3>
            <p>Rp 95.000</p>
            <a href="detail_produk.php?id_produk=1" class="cta-button">Lihat Detail</a>
          </div>
          <div class="product-item">
            <img src="img/jeans.jpg" alt="Jeans Boyfriend" />
            <h3>Jeans Boyfriend</h3>
            <p>Rp 130.000</p>
            <a href="detail_produk.php?id_produk=2" class="cta-button">Lihat Detail</a>
          </div>
          <div class="product-item">
            <img src="img/sweeter.jpg" alt="Sweater Rajut" />
            <h3>Sweater Rajut</h3>
            <p>Rp 110.000</p>
            <a href="detail_produk.php?id_produk=3" class="cta-button">Lihat Detail</a>
          </div>
          <div class="product-item">
            <img src="img/hoodie.jpg" alt="Hoodie Oversize" />
            <h3>Hoodie Oversize</h3>
            <p>Rp 145.000</p>
            <a href="detail_produk.php?id_produk=4" class="cta-button">Lihat Detail</a>
          </div>
          <div class="product-item">
            <img src="img/rok.jpg" alt="Rok Vintage" />
            <h3>Rok Vintage</h3>
            <p>Rp 85.000</p>
            <a href="detail_produk.php?id_produk=5" class="cta-button">Lihat Detail</a>
          </div>
          <div class="product-item">
            <img src="img/kardigan.jpg" alt="Kardigan Lembut" />
            <h3>Kardigan Lembut</h3>
            <p>Rp 120.000</p>
            <a href="detail_produk.php?id_produk=6" class="cta-button">Lihat Detail</a>
          </div>
        </div>
      </div>
    </section>

    <div style="margin-top: 30px; text-align: center">
      <a
        href="produk.php"
        class="cta-button"
        style="background-color: #222; color: #fff"
      >
        <i class="fas fa-store"></i> Lihat Produk Lainnya
      </a>
    </div>

    <div style="margin-top: 40px; color: gray; text-align: center">
      <p>
        <em>"Untuk melihat koleksi produk kami selengkapnya, silakan klik tombol di atas.".</em>
      </p>
    </div>

    <section id="kontak" class="contact-section">
      <div class="container">
        <h2>Kontak Kami</h2>
        <p>Email: info@thriftpreelove.com</p>
        <p>Telepon: +62 857-0787-9960</p>
        <p>Alamat: Belembem, Lebaksari, Wonorejo, Kab.PAsuruan, Jawa Timur, Indonesia</p>
      </div>
    </section>
  </main>

  <footer>
    <div class="container">
      <p>&copy; 2025 Thriftpreelove. Semua Hak Dilindungi.</p>
    </div>
  </footer>

  </body>
</html>
<?php
// Tutup koneksi database jika Anda membukanya di bagian atas
// if (isset($koneksi)) {
//     mysqli_close($koneksi);
// }
?>
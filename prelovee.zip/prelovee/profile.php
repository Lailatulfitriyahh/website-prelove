<?php
// Aktifkan pelaporan kesalahan PHP untuk debugging.
// HAPUS atau NONAKTIFKAN BARIS INI DI LINGKUNGAN PRODUKSI!
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'koneksi.php'; // Hubungkan ke file koneksi database Anda

// --- Cek Koneksi Database ---
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// --- Pastikan pengguna sudah login ---
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Arahkan ke halaman login
    exit();
}

$user_id = $_SESSION['user_id'];
$user_data = null;
$user_orders = [];
$message = ""; // Untuk pesan status atau error
$current_order_status_filter = $_GET['status'] ?? 'all'; // Ambil filter status dari URL, default 'all'
$status_message_from_action = $_GET['action_status'] ?? ''; // Pesan dari handle_order_action.php

// Tampilkan pesan status dari aksi sebelumnya (misal dari handle_order_action.php)
if (!empty($status_message_from_action)) {
    $message = htmlspecialchars($status_message_from_action);
}


// --- 1. Ambil Data Profil Pengguna ---
$stmt_user = mysqli_prepare($koneksi, "SELECT nama, username, email FROM users WHERE id = ?");
if ($stmt_user) {
    mysqli_stmt_bind_param($stmt_user, "i", $user_id);
    mysqli_stmt_execute($stmt_user);
    $result_user = mysqli_stmt_get_result($stmt_user);
    if ($result_user && mysqli_num_rows($result_user) > 0) {
        $user_data = mysqli_fetch_assoc($result_user);
    } else {
        $message .= "Data profil tidak ditemukan. Harap hubungi administrator.";
        error_log("Failed to fetch user profile for profile page: " . mysqli_error($koneksi));
    }
    mysqli_stmt_close($stmt_user);
} else {
    $message .= "Kesalahan persiapan query profil: " . mysqli_error($koneksi);
    error_log("Failed to prepare user profile query for profile page: " . mysqli_error($koneksi));
}

// --- 2. Ambil Riwayat Pesanan Pengguna Berdasarkan Filter Status ---
$order_status_condition = "";
if ($current_order_status_filter != 'all') {
    // PETUNJUK: Sesuaikan dengan nilai order_status di database Anda!
    // Ini harus MATCH dengan nilai yang Anda simpan di kolom 'order_status'
    switch ($current_order_status_filter) {
        case 'pending_payment': $order_status_condition = "AND order_status = 'Pending'"; break; // Belum Bayar
        case 'processing':      $order_status_condition = "AND order_status = 'Processing'"; break; // Sedang Dikemas
        case 'shipped':         $order_status_condition = "AND order_status = 'Shipped'"; break; // Dikirim
        case 'completed':       $order_status_condition = "AND order_status = 'Completed'"; break; // Selesai
        case 'cancelled':       $order_status_condition = "AND order_status = 'Cancelled'"; break; // Dibatalkan
        case 'returned':        $order_status_condition = "AND order_status = 'Returned'"; break; // Pengembalian Barang
        default: $order_status_condition = ""; // Fallback to 'all' if invalid filter
    }
}

// Pastikan kolom `no_pesanan` ada di tabel `orders` jika digunakan
$query_orders_sql = "SELECT order_id, no_pesanan, order_date, total_amount, order_status, customer_name
                     FROM orders
                     WHERE user_id = ? $order_status_condition
                     ORDER BY order_date DESC";

$stmt_orders = mysqli_prepare($koneksi, $query_orders_sql);

if ($stmt_orders) {
    mysqli_stmt_bind_param($stmt_orders, "i", $user_id);
    mysqli_stmt_execute($stmt_orders);
    $result_orders = mysqli_stmt_get_result($stmt_orders);

    if ($result_orders) {
        while ($order = mysqli_fetch_assoc($result_orders)) {
            // --- AMBIL ITEM PESANAN DENGAN GAMBAR DARI TABEL PRODUK ---
            // Menggunakan JOIN dengan tabel 'produk' untuk mendapatkan 'gambar_produk'
            $stmt_order_items = mysqli_prepare($koneksi, "SELECT oi.product_name, oi.quantity, oi.price_per_item, p.gambar_produk
                                                            FROM order_items AS oi
                                                            JOIN produk AS p ON oi.product_id = p.id_produk
                                                            WHERE oi.order_id = ?");
            $items = [];
            if ($stmt_order_items) {
                mysqli_stmt_bind_param($stmt_order_items, "i", $order['order_id']);
                mysqli_stmt_execute($stmt_order_items);
                $result_order_items = mysqli_stmt_get_result($stmt_order_items);
                if ($result_order_items) {
                    while ($item = mysqli_fetch_assoc($result_order_items)) {
                        $items[] = $item;
                    }
                } else {
                    error_log("Failed to get order items with product images for order_id " . $order['order_id'] . ": " . mysqli_error($koneksi));
                }
                mysqli_stmt_close($stmt_order_items);
            } else {
                error_log("Failed to prepare order items query with product images for order_id " . $order['order_id'] . ": " . mysqli_error($koneksi));
            }
            $order['items'] = $items; // Tambahkan item ke dalam array pesanan

            $user_orders[] = $order;
        }
    } else {
        $message .= (empty($message) ? "" : "<br>") . "Gagal mengambil riwayat pesanan: " . mysqli_error($koneksi) . ".";
        error_log("Failed to get user orders result: " . mysqli_error($koneksi));
    }
    mysqli_stmt_close($stmt_orders);
} else {
    $message .= (empty($message) ? "" : "<br>") . "Kesalahan persiapan query riwayat pesanan: " . mysqli_error($koneksi) . ".";
    error_log("Failed to prepare user orders query: " . mysqli_error($koneksi));
}

// Tutup koneksi database
if (isset($koneksi)) {
    mysqli_close($koneksi);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Profil Akun - Thriftpreelove</title>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
    <style>
        /* Gaya dasar */
        body {
            font-family: sans-serif;
            margin: 0;
            background-color: #f0f2f5; /* Warna background lebih terang */
        }

        /* Navbar Styling */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: black;
            color: white;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }

        .navbar .logo a {
            color: white;
            font-size: 20px;
            font-weight: bold;
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0 auto;
            flex-grow: 1;
            justify-content: center;
        }

        .nav-links li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .search-container-inline {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }

        .search-container-inline input[type="text"] {
            padding: 8px 15px;
            border: none;
            border-radius: 20px 0 0 20px;
            outline: none;
            width: 220px;
            background-color: white;
            color: #333;
            font-size: 16px;
        }

        .search-container-inline button {
            background-color: #e0b0ff;
            border: none;
            padding: 8px 15px;
            border-radius: 0 20px 20px 0;
            margin-left: -1px;
            cursor: pointer;
            color: black;
            transition: background-color 0.3s ease;
            font-size: 16px;
        }

        .search-container-inline button:hover {
            background-color: #cc99ff;
        }

        .nav-icons {
          display: flex;
          align-items: center;
          gap: 15px;
        }

        .nav-icons a {
          color: white;
          font-size: 18px;
          text-decoration: none;
          transition: color 0.3s ease;
        }

        .nav-icons a:hover {
          color: #e0b0ff;
        }

        .auth-links {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-left: 15px;
        }

        .auth-links a {
            background-color: #4a4a4a;
            padding: 8px 15px;
            border-radius: 8px;
            color: white;
            text-decoration: none;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 80px;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }

        .auth-links a:hover {
            background-color: #666;
            transform: translateY(-1px);
        }

        /* Layout Utama Halaman Profil */
        .profile-page-container {
            display: flex;
            gap: 20px;
            padding: 80px 20px 40px; /* Padding top disesuaikan dengan navbar, bottom untuk footer */
            max-width: 1200px;
            margin: 0 auto;
            align-items: flex-start; /* Align items to the top */
        }

        /* Sidebar Profil Kiri */
        .profile-sidebar {
            flex: 0 0 250px; /* Lebar tetap 250px */
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 20px;
            box-sizing: border-box;
            position: sticky; /* Sticky sidebar */
            top: 100px; /* Sesuaikan dengan tinggi navbar + sedikit margin */
        }

        .profile-avatar-area {
            display: flex;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }

        .profile-avatar-area img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e0b0ff;
            margin-right: 15px;
        }

        .profile-username-edit {
            display: flex;
            flex-direction: column;
        }

        .profile-username-edit span {
            font-weight: bold;
            font-size: 1.1em;
            color: #333;
            margin-bottom: 5px;
        }

        .profile-username-edit a {
            color: #555;
            text-decoration: none;
            font-size: 0.9em;
            transition: color 0.3s ease;
        }

        .profile-username-edit a:hover {
            color: #e0b0ff;
        }

        .sidebar-menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu li a {
            display: block;
            padding: 12px 15px;
            color: #555;
            text-decoration: none;
            font-weight: 500;
            border-radius: 5px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }

        .sidebar-menu li a:hover,
        .sidebar-menu li a.active {
            background-color: #f0f2f5;
            color: #e0b0ff;
            font-weight: bold;
        }
        .sidebar-menu li a i {
            margin-right: 10px;
            font-size: 1.1em;
            width: 20px; /* Fixed width for icon alignment */
            text-align: center;
        }

        /* Konten Utama Profil Kanan */
        .profile-content {
            flex: 1; /* Ambil sisa lebar yang tersedia */
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 25px;
            box-sizing: border-box;
        }

        .order-filter-tabs {
            display: flex;
            border-bottom: 1px solid #eee;
            margin-bottom: 20px;
            overflow-x: auto; /* Scroll horizontal jika terlalu banyak tab */
            -webkit-overflow-scrolling: touch; /* Untuk smooth scrolling di iOS */
        }

        .order-filter-tabs a {
            flex: 1; /* Bagi rata lebar antar tab */
            min-width: 120px; /* Minimal lebar tab */
            padding: 12px 15px;
            text-align: center;
            text-decoration: none;
            color: #777;
            font-weight: 600;
            border-bottom: 2px solid transparent;
            transition: all 0.3s ease;
        }

        .order-filter-tabs a:hover {
            color: #e0b0ff;
        }

        .order-filter-tabs a.active {
            color: #e0b0ff;
            border-bottom-color: #e0b0ff;
            font-weight: bold;
        }

        .search-orders-bar {
            display: flex;
            margin-bottom: 25px;
            padding: 10px;
            background-color: #f8f8f8;
            border-radius: 8px;
        }
        .search-orders-bar input[type="text"] {
            flex-grow: 1;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            outline: none;
            font-size: 1em;
            margin-right: 10px;
        }
        .search-orders-bar button {
            background-color: #e0b0ff;
            color: black;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            font-size: 1em;
        }
        .search-orders-bar button:hover {
            background-color: #cc99ff;
        }

        .order-list {
            /* Gaya untuk daftar pesanan */
        }

        .order-card {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            margin-bottom: 20px;
            overflow: hidden; /* Clear floats */
            background-color: #fff;
            box-shadow: 0 1px 4px rgba(0,0,0,0.05);
        }

        .order-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            background-color: #fcfcfc;
            border-bottom: 1px solid #eee;
            font-size: 0.95em;
        }

        .order-header .store-info {
            font-weight: bold;
            color: #333;
        }
        .order-header .store-info i {
            margin-right: 5px;
            color: #e0b0ff;
        }

        .order-header .order-status-info {
            color: #e0b0ff; /* Contoh: Warna untuk status selesai */
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .order-status-info i { /* Icon for status info */
            margin-right: 5px;
            font-size: 1.1em;
        }
        /* Styles for different order statuses */
        .order-status-info.pending { color: #f39c12; } /* Orange */
        .order-status-info.processing { color: #3498db; } /* Blue */
        .order-status-info.shipped { color: #2ecc71; } /* Green */
        .order-status-info.completed { color: #e0b0ff; } /* Purple/Pink */
        .order-status-info.cancelled { color: #e74c3c; } /* Red */
        .order-status-info.returned { color: #9b59b6; } /* Violet */


        .order-item-detail {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #eee;
        }

        .order-item-detail:last-of-type {
            border-bottom: none; /* No border for the last item in an order */
        }

        .order-item-detail img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
            margin-right: 15px;
        }

        .order-item-info {
            flex-grow: 1;
        }
        .order-item-info .product-name {
            font-weight: bold;
            color: #333;
            margin-bottom: 5px;
        }
        .order-item-info .quantity {
            font-size: 0.9em;
            color: #777;
        }
        .order-item-price {
            font-weight: bold;
            color: #333;
            font-size: 1.1em;
            margin-left: 20px;
        }

        .order-summary-footer {
            padding: 15px;
            text-align: right;
            border-top: 1px solid #eee;
            background-color: #fcfcfc;
        }
        .order-summary-footer .total-amount {
            font-size: 1.4em;
            font-weight: bold;
            color: #e0b0ff;
            margin-bottom: 10px;
        }
        .order-summary-footer .action-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        .order-summary-footer .action-buttons button {
            background-color: #e0b0ff;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9em;
            font-weight: bold;
            color: black;
            transition: background-color 0.3s ease;
        }
        .order-summary-footer .action-buttons button:hover {
            background-color: #cc99ff;
        }
        .order-summary-footer .action-buttons .btn-secondary {
            background-color: #f0f0f0;
            color: #555;
        }
        .order-summary-footer .action-buttons .btn-secondary:hover {
            background-color: #e0e0e0;
        }
        .order-summary-footer .action-buttons .btn-danger { /* For 'Cancel' button */
            background-color: #dc3545;
            color: white;
        }
        .order-summary-footer .action-buttons .btn-danger:hover {
            background-color: #c82333;
        }

        .no-orders-found {
            text-align: center;
            padding: 30px;
            color: #777;
            font-size: 1.1em;
            background-color: #f8f8f8;
            border-radius: 8px;
        }

        .status-message-box { /* Generic message box for status */
            background-color: #d4edda; /* Light green for success */
            color: #155724; /* Dark green text */
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }
        .status-message-box.error {
            background-color: #f8d7da; /* Light red for errors */
            color: #721c24; /* Dark red text */
        }


        /* Footer */
        footer {
            background-color: #222;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 20px; /* Tambahkan margin agar tidak terlalu dekat dengan konten */
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .profile-page-container {
                flex-direction: column;
                padding-top: 70px; /* Adjust for smaller screens */
            }
            .profile-sidebar {
                width: 100%;
                position: static; /* No longer sticky on small screens */
                margin-bottom: 20px;
            }
            .order-filter-tabs {
                justify-content: flex-start; /* Align tabs to start */
            }
            .order-filter-tabs a {
                flex-shrink: 0; /* Don't shrink tabs */
            }
            .order-header, .order-item-detail {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            .order-header .order-status-info {
                width: 100%;
                justify-content: flex-end;
            }
            .order-item-price {
                margin-left: 0;
                width: 100%;
                text-align: right;
            }
            .order-summary-footer .action-buttons {
                flex-direction: column;
                align-items: stretch;
            }
            .order-summary-footer .action-buttons button {
                width: 100%;
                margin-left: 0;
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>

    <header>
        <nav class="navbar">
            <div class="logo">
                <a href="index.html#home">thriftpreelove.</a>
            </div>
            <ul class="nav-links">
                <li><a href="index.html#home">Home</a></li>
                <li><a href="index.html#tentang-kami">Tentang Kami</a></li>
                <li><a href="produk.php">Produk</a></li>
                <li><a href="index.html#kontak">Kontak</a></li>
            </ul>

            <div class="search-container-inline">
                <form action="search.php" method="GET" style="display: flex;">
                    <input type="text" name="query" placeholder="Cari produk...">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>

            <div style="display: flex; align-items: center">
                <div class="nav-icons">
                    <a href="cart.php" class="cart-icon" title="Lihat Keranjang">
                        <i class="fas fa-shopping-cart"></i>
                    </a>
                </div>

                <div class="auth-links">
                    <a href="profile.php">Profil</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="profile-page-container">
            <aside class="profile-sidebar">
                <?php if ($user_data): ?>
                <div class="profile-avatar-area">
                    <img src="img/cintaku.jpg" alt="User Avatar"> <div class="profile-username-edit">
                        <span><?php echo htmlspecialchars($user_data['username']); ?></span>
                        <a href="edit_profile.php"><i class="fas fa-edit"></i> Ubah Profil</a>
                    </div>
                </div>

                <nav class="sidebar-menu">
                    <ul>
                        <li><a href="profile.php"><i class="fas fa-user"></i> Akun Saya</a></li>
                        <li><a href="profile.php?status=all" class="<?php echo ($current_order_status_filter != 'all') ? '' : 'active'; ?>"><i class="fas fa-clipboard-list"></i> Pesanan Saya</a></li>
                        <li><a href="notifications.php"><i class="fas fa-bell"></i> Notifikasi</a></li>
                        </ul>
                </nav>
                <?php else: ?>
                    <p style="text-align: center; color: #777;">Memuat profil...</p>
                <?php endif; ?>
            </aside>

            <section class="profile-content">
                <div class="order-filter-tabs">
                    <a href="profile.php?status=all" class="<?php echo ($current_order_status_filter == 'all') ? 'active' : ''; ?>">Semua</a>
                    <a href="profile.php?status=pending_payment" class="<?php echo ($current_order_status_filter == 'pending_payment') ? 'active' : ''; ?>">Belum Bayar</a>
                    <a href="profile.php?status=processing" class="<?php echo ($current_order_status_filter == 'processing') ? 'active' : ''; ?>">Sedang Dikemas</a>
                    <a href="profile.php?status=shipped" class="<?php echo ($current_order_status_filter == 'shipped') ? 'active' : ''; ?>">Dikirim</a>
                    <a href="profile.php?status=completed" class="<?php echo ($current_order_status_filter == 'completed') ? 'active' : ''; ?>">Selesai</a>
                    <a href="profile.php?status=cancelled" class="<?php echo ($current_order_status_filter == 'cancelled') ? 'active' : ''; ?>">Dibatalkan</a>
                    <a href="profile.php?status=returned" class="<?php echo ($current_order_status_filter == 'returned') ? 'active' : ''; ?>">Pengembalian Barang</a>
                </div>

                <div class="search-orders-bar">
                    <input type="text" placeholder="Cari berdasarkan Nama Penjual, No. Pesanan atau Nama Produk">
                    <button><i class="fas fa-search"></i></button>
                </div>

                <div class="order-list">
                    <?php if (!empty($message)): ?>
                        <p class="status-message-box <?php echo (strpos($message, 'berhasil') !== false || strpos($message, 'sukses') !== false) ? 'success' : 'error'; ?>"><?php echo htmlspecialchars($message); ?></p>
                    <?php endif; ?>

                    <?php if (!empty($user_orders)): ?>
                        <?php foreach ($user_orders as $order): ?>
                            <div class="order-card">
                                <div class="order-header">
                                    <div class="store-info">
                                        <i class="fas fa-store"></i> Thriftpreelove.store
                                        </div>
                                    <div class="order-status-info <?php echo strtolower(htmlspecialchars($order['order_status'])); ?>">
                                        <i class="fas fa-info-circle"></i>
                                        <?php echo htmlspecialchars($order['order_status']); ?>
                                        <?php if (!empty($order['no_pesanan'])): ?>
                                            (#<?php echo htmlspecialchars($order['no_pesanan']); ?>)
                                        <?php endif; ?>
                                        <span class="order-date">Pesanan pada: <?php echo date('d-m-Y', strtotime($order['order_date'])); ?></span>
                                    </div>
                                </div>

                                <?php if (!empty($order['items'])): ?>
                                    <?php foreach ($order['items'] as $item): ?>
                                        <div class="order-item-detail">
                                            <img src="img/<?php echo htmlspecialchars($item['gambar_produk'] ?? 'item_placeholder.jpg'); ?>" alt="<?php echo htmlspecialchars($item['product_name']); ?>">
                                            <div class="order-item-info">
                                                <div class="product-name"><?php echo htmlspecialchars($item['product_name']); ?></div>
                                                <div class="quantity">x<?php echo htmlspecialchars($item['quantity']); ?></div>
                                            </div>
                                            <div class="order-item-price">Rp <?php echo number_format($item['price_per_item'], 0, ',', '.'); ?></div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="order-item-detail" style="font-style: italic; color: #888;">Tidak ada item yang terdaftar untuk pesanan ini.</div>
                                <?php endif; ?>

                                <div class="order-summary-footer">
                                    <div class="total-amount">
                                        Total Pesanan: Rp <?php echo number_format($order['total_amount'], 0, ',', '.'); ?>
                                    </div>
                                    <div class="action-buttons">
                                        <?php if ($order['order_status'] == 'Pending'): ?>
                                            <form action="handle_order_action.php" method="POST" style="display:inline;">
                                                <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($order['order_id']); ?>">
                                                <input type="hidden" name="action" value="pay">
                                                <button type="submit">Bayar Sekarang</button>
                                            </form>
                                            <form action="handle_order_action.php" method="POST" style="display:inline;">
                                                <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($order['order_id']); ?>">
                                                <input type="hidden" name="action" value="cancel">
                                                <button type="submit" class="btn-danger">Batalkan Pesanan</button>
                                            </form>
                                        <?php elseif ($order['order_status'] == 'Completed'): ?>
                                            <button>Nilai</button>
                                            <button class="btn-secondary">Hubungi Penjual</button>
                                            <button>Beli Lagi</button>
                                        <?php elseif ($order['order_status'] == 'Cancelled'): ?>
                                            <button class="btn-secondary">Lihat Detail</button>
                                        <?php endif; ?>
                                        </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-orders-found">
                            <i class="fas fa-box-open fa-3x" style="margin-bottom: 15px; color: #ccc;"></i>
                            <p>Anda belum memiliki pesanan dengan status '<?php echo htmlspecialchars($current_order_status_filter); ?>'.</p>
                            <p><a href="produk.php" style="color: #e0b0ff; text-decoration: none;">Mulai belanja sekarang!</a></p>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </main>

    <footer>
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> Thriftpreelove. Semua Hak Dilindungi.</p>
        </div>
    </footer>
</body>
</html>
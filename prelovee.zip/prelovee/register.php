<?php
// Aktifkan pelaporan kesalahan PHP untuk debugging (HAPUS ATAU NONAKTIFKAN DI PRODUKSI)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'koneksi.php'; // Hubungkan ke file koneksi database Anda

// --- Cek Koneksi Database ---
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

$message = '';
$username_val = $_POST['username'] ?? '';
$nama_val = $_POST['nama'] ?? '';
$email_val = $_POST['email'] ?? '';
$no_hp_val = $_POST['no_hp'] ?? '';
$alamat_val = $_POST['alamat'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari POST dan bersihkan
    $username = trim($_POST['username'] ?? '');
    $nama = trim($_POST['nama'] ?? ''); // Kolom 'nama' untuk nama lengkap
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $no_hp = trim($_POST['no_hp'] ?? ''); // Kolom 'no_hp'
    $alamat = trim($_POST['alamat'] ?? ''); // Kolom 'alamat'

    // Validasi dasar
    if (empty($username) || empty($nama) || empty($email) || empty($password) || empty($confirm_password)) {
        $message = "Harap isi semua kolom yang wajib diisi.";
    } elseif ($password !== $confirm_password) {
        $message = "Konfirmasi password tidak cocok.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Format email tidak valid.";
    } else {
        // --- Cek apakah username atau email sudah terdaftar (menggunakan Prepared Statement) ---
        $stmt_check = mysqli_prepare($koneksi, "SELECT id FROM users WHERE username = ? OR email = ?");
        if ($stmt_check) {
            mysqli_stmt_bind_param($stmt_check, "ss", $username, $email);
            mysqli_stmt_execute($stmt_check);
            mysqli_stmt_store_result($stmt_check); // Simpan hasil agar bisa dicek jumlah barisnya

            if (mysqli_stmt_num_rows($stmt_check) > 0) {
                $message = "Username atau email sudah digunakan. Mohon pilih yang lain.";
            } else {
                // --- Insert pengguna baru (menggunakan Prepared Statement) ---
                $password_hash = password_hash($password, PASSWORD_DEFAULT);

                $stmt_insert = mysqli_prepare($koneksi, "INSERT INTO users (username, nama, email, password_hash, no_hp, alamat) VALUES (?, ?, ?, ?, ?, ?)");
                if ($stmt_insert) {
                    mysqli_stmt_bind_param($stmt_insert, "ssssss", $username, $nama, $email, $password_hash, $no_hp, $alamat);

                    if (mysqli_stmt_execute($stmt_insert)) {
                        header('Location: login.php?success=registered');
                        exit();
                    } else {
                        $message = "Gagal mendaftar. Terjadi kesalahan database: " . mysqli_stmt_error($stmt_insert);
                        error_log("Failed to register user: " . mysqli_stmt_error($stmt_insert));
                    }
                    mysqli_stmt_close($stmt_insert);
                } else {
                    $message = "Kesalahan persiapan query pendaftaran: " . mysqli_error($koneksi);
                    error_log("Failed to prepare registration query: " . mysqli_error($koneksi));
                }
            }
            mysqli_stmt_close($stmt_check);
        } else {
            $message = "Kesalahan persiapan cek username/email: " . mysqli_error($koneksi);
            error_log("Failed to prepare username/email check query: " . mysqli_error($koneksi));
        }
    }
}

// Tutup koneksi database
if (isset($koneksi)) {
    mysqli_close($koneksi);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar - Thriftpreelove</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
    <style>
        /* Navbar Styling - Consistent with other pages */
        body {
            font-family: sans-serif;
            margin: 0;
            background-color: #f9f9f9; /* Consistent background */
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: black;
            color: white;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .navbar .logo a {
            color: white;
            font-size: 20px;
            font-weight: bold;
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0 auto;
            flex-grow: 1;
            justify-content: center;
        }

        .nav-links li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .search-container-inline {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }

        .search-container-inline input[type="text"] {
            padding: 8px 15px;
            border: none;
            border-radius: 20px 0 0 20px;
            outline: none;
            width: 220px;
            background-color: white;
            color: #333;
            font-size: 16px;
        }

        .search-container-inline button {
            background-color: #e0b0ff;
            border: none;
            padding: 8px 15px;
            border-radius: 0 20px 20px 0;
            margin-left: -1px;
            cursor: pointer;
            color: black;
            transition: background-color 0.3s ease;
            font-size: 16px;
        }

        .search-container-inline button:hover {
            background-color: #cc99ff;
        }

        .nav-icons {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .nav-icons a {
            color: white;
            font-size: 18px;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .nav-icons a:hover {
            color: #e0b0ff;
        }

        .auth-links {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-left: 15px;
        }

        .auth-links a {
            background-color: #e0b0ff; /* Keep original login/register button style */
            padding: 6px 12px;
            border-radius: 20px;
            color: black !important;
            text-decoration: none;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: background-color 0.3s ease;
        }

        .auth-links a:hover {
            background-color: #cc99ff;
        }

        /* Gaya Khusus Halaman Daftar */
        .register-section { /* Mengubah .register-container menjadi .register-section agar konsisten dengan halaman lain */
            padding-top: 80px; /* Menyesuaikan dengan tinggi navbar fixed */
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: calc(100vh - 60px); /* Adjust min-height for navbar */
            background-color: #f9f9f9; /* Consistent background */
        }
        .register-form-box { /* Mengubah .register-form agar tidak bentrok dengan form tag */
            background-color: #fff;
            padding: 40px;
            border-radius: 10px; /* Sedikit lebih membulat */
            box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* Shadow yang konsisten */
            width: 100%;
            max-width: 450px; /* Batasi lebar maksimum */
            text-align: center;
        }
        .register-form-box h2 {
            margin-bottom: 25px; /* Menambah margin */
            color: #333;
            font-size: 2.2em; /* Ukuran font konsisten */
        }
        .form-group { /* Grouping input for better control */
            margin-bottom: 15px;
            text-align: left; /* Align labels/inputs to left */
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        .register-form-box input[type="text"],
        .register-form-box input[type="email"],
        .register-form-box input[type="password"],
        .register-form-box textarea { /* Add textarea style */
            width: calc(100% - 22px); /* Full width with padding/border consideration */
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px; /* Consistent border-radius */
            margin-bottom: 0; /* Remove default margin-bottom from input type */
            font-size: 1em; /* Consistent font size */
            box-sizing: border-box; /* Include padding and border in width */
        }
        .register-form-box textarea {
            resize: vertical; /* Allow vertical resize */
            min-height: 80px;
        }
        .register-button { /* Rename for clarity and consistency */
            background-color: #e0b0ff;
            color: #000;
            padding: 12px 25px; /* Consistent padding */
            border: none;
            border-radius: 25px; /* Consistent border-radius */
            cursor: pointer;
            font-size: 1.1em; /* Consistent font size */
            width: 100%;
            margin-top: 25px; /* Adjust margin */
            font-weight: bold; /* Consistent font weight */
            transition: background-color 0.3s ease;
        }
        .register-button:hover {
            background-color: #cc99ff;
        }
        .message-box { /* Consistent message box style */
            background-color: #ffe0b0; /* Light orange for warnings/errors */
            color: #d35400; /* Darker orange text */
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }
        .login-link {
            margin-top: 20px;
            font-size: 0.95em;
            color: #777;
        }
        .login-link a {
            color: #e0b0ff;
            text-decoration: none;
            font-weight: bold;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        /* Footer */
        footer {
            background-color: #222;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 0; /* Remove top margin as section has min-height */
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <a href="index.html#home">thriftpreelove.</a>
            </div>
            <ul class="nav-links">
                <li><a href="index.html#home">Home</a></li>
                <li><a href="index.html#tentang-kami">Tentang Kami</a></li>
                <li><a href="produk.php">Produk</a></li>
                <li><a href="index.html#kontak">Kontak</a></li>
            </ul>

            <div class="search-container-inline">
                <form action="search.php" method="GET" style="display: flex;">
                    <input type="text" name="query" placeholder="Cari produk...">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>

            <div class="auth-links">
                <a href="login.php">Login</a>
                </div>
        </nav>
    </header>

    <main>
        <section class="register-section">
            <div class="register-form-box">
                <h2>Daftar Akun Baru</h2>
                <?php if (!empty($message)): ?>
                    <p class="message-box"><?php echo htmlspecialchars($message); ?></p>
                <?php endif; ?>
                <form action="register.php" method="POST">
                    <div class="form-group">
                        <label for="username">Username:</label>
                        <input type="text" id="username" name="username" placeholder="Username unik Anda" value="<?php echo htmlspecialchars($username_val); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="nama">Nama Lengkap:</label>
                        <input type="text" id="nama" name="nama" placeholder="Nama lengkap Anda" value="<?php echo htmlspecialchars($nama_val); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" placeholder="Alamat email Anda" value="<?php echo htmlspecialchars($email_val); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" id="password" name="password" placeholder="Password Anda" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Konfirmasi Password:</label>
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="Ketik ulang password" required>
                    </div>
                    <div class="form-group">
                        <label for="no_hp">Nomor Telepon (Opsional):</label>
                        <input type="text" id="no_hp" name="no_hp" placeholder="Contoh: 081234567890" value="<?php echo htmlspecialchars($no_hp_val); ?>">
                    </div>
                    <div class="form-group">
                        <label for="alamat">Alamat (Opsional):</label>
                        <textarea id="alamat" name="alamat" placeholder="Alamat lengkap Anda"><?php echo htmlspecialchars($alamat_val); ?></textarea>
                    </div>
                    <button type="submit" class="register-button">Daftar Sekarang</button>
                </form>
                <p class="login-link">Sudah punya akun? <a href="login.php">Login di sini</a></p>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> Thriftpreelove. Semua Hak Dilindungi.</p>
        </div>
    </footer>
</body>
</html>
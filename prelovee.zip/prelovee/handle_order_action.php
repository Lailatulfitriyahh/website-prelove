<?php
// Aktifkan pelaporan kesalahan PHP untuk debugging.
// HAPUS atau NONAKTIFKAN BARIS INI DI LINGKUNGAN PRODUKSI!
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'koneksi.php'; // Hubungkan ke file koneksi database Anda

// --- Pastikan hanya request POST yang diterima ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Jika bukan request POST, redirect kembali dengan pesan error
    header('Location: profile.php?action_status=' . urlencode('Metode request tidak diizinkan.'));
    exit();
}

// --- Pastikan pengguna sudah login ---
if (!isset($_SESSION['user_id'])) {
    // Jika belum login, redirect ke halaman login dengan pesan
    header('Location: login.php?action_status=' . urlencode('Anda harus login untuk melakukan aksi ini.'));
    exit();
}

$user_id = $_SESSION['user_id']; // Ambil ID pengguna dari sesi
$order_id = $_POST['order_id'] ?? null; // Ambil ID pesanan dari form POST
$action = $_POST['action'] ?? null;     // Ambil aksi yang diminta (e.g., 'pay', 'cancel')
$status_message = ''; // Variabel untuk menyimpan pesan status yang akan dikirim kembali

if ($order_id && $action) {
    // Pastikan order_id adalah integer untuk keamanan tambahan dan binding parameter
    $order_id = (int)$order_id;

    // --- Mulai Transaksi Database ---
    // Transaksi memastikan bahwa semua operasi dalam blok ini berhasil sepenuhnya
    // atau jika ada yang gagal, semuanya akan dibatalkan (rollback).
    mysqli_begin_transaction($koneksi);

    try {
        switch ($action) {
            case 'pay':
                // --- Aksi 'Bayar Sekarang' ---
                // Perbarui status pesanan menjadi 'Processing'.
                // Kritis: Pastikan pesanan adalah milik user yang sedang login
                // DAN status pesanan saat ini adalah 'Pending' sebelum diubah.
                $stmt = mysqli_prepare($koneksi, "UPDATE orders SET order_status = 'Processing', updated_at = CURRENT_TIMESTAMP WHERE order_id = ? AND user_id = ? AND order_status = 'Pending'");
                
                if (!$stmt) {
                    throw new Exception("Gagal mempersiapkan query Bayar: " . mysqli_error($koneksi));
                }
                mysqli_stmt_bind_param($stmt, "ii", $order_id, $user_id); // "ii" menandakan dua parameter integer
                mysqli_stmt_execute($stmt);

                // Periksa apakah ada baris yang terpengaruh (artinya update berhasil)
                if (mysqli_stmt_affected_rows($stmt) > 0) {
                    $status_message = "Pesanan berhasil dibayar dan sedang diproses!";
                } else {
                    // Ini bisa berarti:
                    // 1. Pesanan tidak ditemukan dengan order_id yang diberikan.
                    // 2. Pesanan bukan milik user yang sedang login.
                    // 3. Status pesanan sudah bukan 'Pending' lagi (misalnya sudah dibatalkan atau selesai).
                    $status_message = "Gagal memproses pembayaran pesanan. Mungkin status pesanan sudah berubah atau pesanan tidak valid.";
                }
                mysqli_stmt_close($stmt);
                break;

            case 'cancel':
                // --- Aksi 'Batalkan Pesanan' ---
                // Perbarui status pesanan menjadi 'Cancelled'.
                // Kritis: Pastikan pesanan adalah milik user yang sedang login
                // DAN statusnya adalah 'Pending' atau 'Processing' sebelum dibatalkan.
                $stmt = mysqli_prepare($koneksi, "UPDATE orders SET order_status = 'Cancelled', updated_at = CURRENT_TIMESTAMP WHERE order_id = ? AND user_id = ? AND (order_status = 'Pending' OR order_status = 'Processing')");
                
                if (!$stmt) {
                    throw new Exception("Gagal mempersiapkan query Batalkan: " . mysqli_error($koneksi));
                }
                mysqli_stmt_bind_param($stmt, "ii", $order_id, $user_id);
                mysqli_stmt_execute($stmt);

                // Periksa apakah ada baris yang terpengaruh
                if (mysqli_stmt_affected_rows($stmt) > 0) {
                    $status_message = "Pesanan berhasil dibatalkan.";
                    // PETUNJUK: Jika Anda memiliki sistem stok, ini adalah tempat yang tepat
                    // untuk menambahkan logika pengembalian stok produk yang dibatalkan.
                    // Contoh: UPDATE produk SET stock = stock + ? WHERE id_produk = ?;
                } else {
                    // Ini bisa berarti:
                    // 1. Pesanan tidak ditemukan.
                    // 2. Pesanan bukan milik user.
                    // 3. Status pesanan tidak memungkinkan untuk dibatalkan (misalnya sudah 'Shipped' atau 'Completed').
                    $status_message = "Gagal membatalkan pesanan. Mungkin status pesanan sudah tidak bisa dibatalkan atau pesanan tidak valid.";
                }
                mysqli_stmt_close($stmt);
                break;

            default:
                // Jika aksi yang diminta tidak dikenali
                $status_message = "Aksi tidak valid.";
                break;
        }
        mysqli_commit($koneksi); // Commit transaksi jika semua operasi berhasil dalam blok try
    } catch (Exception $e) {
        // Jika terjadi error di dalam blok try, batalkan semua perubahan transaksi
        mysqli_rollback($koneksi);
        $status_message = "Terjadi kesalahan saat melakukan aksi: " . $e->getMessage();
        // Log error untuk debugging lebih lanjut
        error_log("Order action failed: " . $e->getMessage() . " for user " . $user_id . ", order " . $order_id . ", action " . $action);
    }
} else {
    // Jika order_id atau action tidak disediakan di POST request
    $status_message = "ID Pesanan atau Aksi tidak valid.";
}

// Tutup koneksi database
if (isset($koneksi)) {
    mysqli_close($koneksi);
}

// --- Redirect kembali ke halaman profil dengan pesan status ---
// Pesan status akan dikirim melalui parameter GET 'action_status'
header('Location: profile.php?action_status=' . urlencode($status_message));
exit(); // Hentikan eksekusi script setelah redirect
?>
<?php
session_start(); // Mulai session untuk akses data jika diperlukan, meskipun tidak ada data session yang digunakan langsung di sini
include 'koneksi.php'; // Hubungkan ke file koneksi database Anda

$order_id = $_GET['order_id'] ?? null;
$order_details = null;
$order_items = [];
$error_message = "";

if ($order_id) {
    // Gunakan prepared statement untuk keamanan yang lebih baik
    $stmt_order = mysqli_prepare($koneksi, "SELECT * FROM orders WHERE order_id = ?");
    mysqli_stmt_bind_param($stmt_order, "s", $order_id);
    mysqli_stmt_execute($stmt_order);
    $result_order = mysqli_stmt_get_result($stmt_order);

    if ($result_order && mysqli_num_rows($result_order) > 0) {
        $order_details = mysqli_fetch_assoc($result_order);
        mysqli_stmt_close($stmt_order); // Tutup statement order

        // Query untuk mengambil item-item pesanan dari tabel order_items
        $stmt_items = mysqli_prepare($koneksi, "SELECT * FROM order_items WHERE order_id = ?");
        mysqli_stmt_bind_param($stmt_items, "s", $order_id);
        mysqli_stmt_execute($stmt_items);
        $result_items = mysqli_stmt_get_result($stmt_items);

        if ($result_items) {
            while ($item = mysqli_fetch_assoc($result_items)) {
                $order_items[] = $item;
            }
            mysqli_stmt_close($stmt_items); // Tutup statement items
        } else {
            $error_message = "Gagal mengambil detail item pesanan: " . mysqli_error($koneksi);
        }

    } else {
        $error_message = "Pesanan tidak ditemukan atau ID pesanan tidak valid.";
    }
} else {
    $error_message = "ID Pesanan tidak disediakan. Tidak dapat menampilkan konfirmasi.";
}

// Tutup koneksi database
if (isset($koneksi)) {
    mysqli_close($koneksi);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Konfirmasi Pesanan - Thriftpreelove</title>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
    <style>
        /* Gaya dasar */
        body {
            font-family: sans-serif;
            margin: 0;
            background-color: #f9f9f9;
        }

        /* Navbar Styling - Consistent with other pages */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: black;
            color: white;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .navbar .logo a {
            color: white;
            font-size: 20px;
            font-weight: bold;
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0 auto;
            flex-grow: 1;
            justify-content: center;
        }

        .nav-links li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .search-container-inline {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }

        .search-container-inline input[type="text"] {
            padding: 8px 15px;
            border: none;
            border-radius: 20px 0 0 20px;
            outline: none;
            width: 220px;
            background-color: white;
            color: #333;
            font-size: 16px;
        }

        .search-container-inline button {
            background-color: #e0b0ff;
            border: none;
            padding: 8px 15px;
            border-radius: 0 20px 20px 0;
            margin-left: -1px;
            cursor: pointer;
            color: black;
            transition: background-color 0.3s ease;
            font-size: 16px;
        }

        .search-container-inline button:hover {
            background-color: #cc99ff;
        }

        .nav-icons {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .nav-icons a {
            color: white;
            font-size: 18px;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        .nav-icons a:hover {
            color: #e0b0ff;
        }

        .auth-links {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-left: 15px;
        }

        .auth-links a {
            background-color: #4a4a4a;
            padding: 8px 15px;
            border-radius: 8px;
            color: white;
            text-decoration: none;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 80px;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }

        .auth-links a:hover {
            background-color: #666;
            transform: translateY(-1px);
        }

        /* Gaya Khusus Halaman Konfirmasi */
        .confirmation-section {
            padding: 80px 20px;
            text-align: center;
            max-width: 800px;
            margin: 20px auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .confirmation-section h2 {
            font-size: 2.5em;
            color: #333;
            margin-bottom: 10px;
        }

        .confirmation-section .icon-success {
            color: #4CAF50; /* Green checkmark */
            font-size: 4em;
            margin-bottom: 20px;
        }

        .confirmation-section .message-success {
            font-size: 1.2em;
            color: #333;
            margin-bottom: 30px;
        }

        .confirmation-section .error-message {
            background-color: #f8d7da; /* Light red for errors */
            color: #721c24; /* Dark red text */
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 30px;
            font-weight: bold;
        }

        .order-details-box {
            text-align: left;
            border: 1px solid #eee;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 30px;
            background-color: #fdfdfd;
        }

        .order-details-box h3 {
            font-size: 1.5em;
            color: #333;
            margin-top: 0;
            margin-bottom: 15px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }

        .order-details-box p {
            margin-bottom: 8px;
            color: #555;
        }

        .order-details-box p strong {
            color: #333;
        }

        .order-items-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-bottom: 20px;
        }

        .order-items-table th, .order-items-table td {
            padding: 10px;
            border: 1px solid #eee;
            text-align: left;
        }

        .order-items-table th {
            background-color: #f2f2f2;
        }

        .order-items-table .item-total {
            font-weight: bold;
            color: #e0b0ff;
        }

        .order-total {
            text-align: right;
            font-size: 1.8em;
            font-weight: bold;
            margin-top: 20px;
            color: #333;
        }

        .cta-button {
            background-color: #e0b0ff;
            border: none;
            padding: 12px 25px;
            border-radius: 25px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            color: black;
            font-size: 1.1em;
            transition: background-color 0.3s ease;
            margin: 5px;
        }

        .cta-button:hover {
            background-color: #cc99ff;
        }

        .cta-button.secondary {
            background-color: #555;
            color: white;
        }

        .cta-button.secondary:hover {
            background-color: #777;
        }

        /* Footer */
        footer {
            background-color: #222;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 40px;
        }
    </style>
</head>
<body>

    <header>
        <nav class="navbar">
            <div class="logo">
                <a href="index.html#home">thriftpreelove.</a>
            </div>
            <ul class="nav-links">
                <li><a href="index.html#home">Home</a></li>
                <li><a href="index.html#tentang-kami">Tentang Kami</a></li>
                <li><a href="produk.php">Produk</a></li>
                <li><a href="index.html#kontak">Kontak</a></li>
            </ul>

            <div class="search-container-inline">
                <form action="search.php" method="GET" style="display: flex;">
                    <input type="text" name="query" placeholder="Cari produk...">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>

            <div style="display: flex; align-items: center">
                <div class="nav-icons">
                    <a href="cart.php" class="cart-icon" title="Lihat Keranjang">
                        <i class="fas fa-shopping-cart"></i>
                    </a>
                </div>

                <div class="auth-links">
                    <a href="profile.php">Profil</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="confirmation-section">
            <?php if (!empty($error_message)): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error_message); ?>
                </div>
                <a href="produk.php" class="cta-button secondary">Kembali ke Produk</a>
                <a href="cart.php" class="cta-button">Lihat Keranjang</a>
            <?php elseif ($order_details): ?>
                <i class="fas fa-check-circle icon-success"></i>
                <h2>Pesanan Berhasil Ditempatkan!</h2>
                <p class="message-success">Terima kasih atas pesanan Anda. Detail pesanan Anda di bawah ini:</p>

                <div class="order-details-box">
                    <h3>Detail Pesanan #<?php echo htmlspecialchars($order_details['order_id']); ?></h3>
                    <p><strong>Nama Pelanggan:</strong> <?php echo htmlspecialchars($order_details['customer_name']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($order_details['customer_email'] ?: 'Tidak ada'); ?></p>
                    <p><strong>Nomor Telepon:</strong> <?php echo htmlspecialchars($order_details['phone_number']); ?></p>
                    <p><strong>Alamat Pengiriman:</strong> <?php echo nl2br(htmlspecialchars($order_details['shipping_address'])); ?></p>
                    <p><strong>Metode Pembayaran:</strong> <?php echo htmlspecialchars($order_details['payment_method']); ?></p>
                    <p><strong>Tanggal Pesanan:</strong> <?php echo date('d M Y H:i', strtotime($order_details['order_date'])); ?></p>
                    <p><strong>Status Pesanan:</strong> <?php echo htmlspecialchars($order_details['order_status']); ?></p>
                </div>

                <h3>Produk yang Dipesan</h3>
                <?php if (!empty($order_items)): ?>
                    <table class="order-items-table">
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Qty</th>
                                <th>Harga Satuan</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($order_items as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                                    <td>Rp <?php echo number_format($item['price_per_item'], 0, ',', '.'); ?></td>
                                    <td class="item-total">Rp <?php echo number_format($item['price_per_item'] * $item['quantity'], 0, ',', '.'); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="order-total">
                        Total Pembayaran: Rp <?php echo number_format($order_details['total_amount'], 0, ',', '.'); ?>
                    </div>
                <?php else: ?>
                    <p>Tidak ada item yang ditemukan untuk pesanan ini.</p>
                <?php endif; ?>

                <div style="margin-top: 30px;">
                    <a href="index.html" class="cta-button">Kembali ke Beranda</a>
                    <a href="produk.php" class="cta-button secondary">Lanjutkan Belanja</a>

                    <?php
                    // Pastikan $order_details dan $order_details['customer_name'] tersedia sebelum digunakan
                    // Ini penting jika ada kasus $order_details ditemukan tapi 'customer_name' tidak ada (meskipun tidak mungkin pada kasus ini)
                    $customer_name_for_whatsapp = $order_details['customer_name'] ?? 'Pelanggan'; // Fallback jika nama tidak ada
                    $whatsapp_message_for_customer = "Halo Thriftpreelove! Saya ingin menanyakan tentang pesanan saya dengan ID: *{$order_details['order_id']}* atas nama *{$customer_name_for_whatsapp}*.";
                    // Ganti 6281234567890 dengan nomor WhatsApp CS/Toko Anda
                    $whatsapp_link = "https://wa.me/6281234567890?text=" . urlencode($whatsapp_message_for_customer);
                    ?>
                    <a href="<?php echo $whatsapp_link; ?>" target="_blank" class="cta-button" style="background-color: #25D366; color: white;">
                        <i class="fab fa-whatsapp"></i> Hubungi Kami (WhatsApp)
                    </a>
                </div>

            <?php else: ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i> Terjadi kesalahan yang tidak terduga.
                </div>
                <a href="produk.php" class="cta-button secondary">Kembali ke Produk</a>
                <a href="cart.php" class="cta-button">Lihat Keranjang</a>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Thriftpreelove. Semua Hak Dilindungi.</p>
        </div>
    </footer>
</body>
</html>
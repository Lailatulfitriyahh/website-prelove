<?php
// Aktifkan pelaporan kesalahan PHP untuk debugging.
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'koneksi.php'; // Hubungkan ke file koneksi database Anda

// --- Cek Koneksi Database ---
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// --- Pastikan pengguna sudah login ---
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Arahkan ke halaman login jika belum login
    exit();
}

$user_id = $_SESSION['user_id'];
$user_data = null; // Data profil untuk sidebar
$notifications = []; // Array untuk menyimpan notifikasi
$message = ""; // Pesan status atau error

// --- 1. Ambil Data Profil Pengguna untuk Sidebar (Sama seperti profile.php) ---
$stmt_user = mysqli_prepare($koneksi, "SELECT nama, username, email FROM users WHERE id = ?");
if ($stmt_user) {
    mysqli_stmt_bind_param($stmt_user, "i", $user_id);
    mysqli_stmt_execute($stmt_user);
    $result_user = mysqli_stmt_get_result($stmt_user);
    if ($result_user && mysqli_num_rows($result_user) > 0) {
        $user_data = mysqli_fetch_assoc($result_user);
    } else {
        $message = "Data profil tidak ditemukan. Harap hubungi administrator.";
        error_log("Failed to fetch user profile for notifications page: " . mysqli_error($koneksi));
    }
    mysqli_stmt_close($stmt_user);
} else {
    $message = "Kesalahan persiapan query profil (notifications): " . mysqli_error($koneksi);
    error_log("Failed to prepare user profile query (notifications): " . mysqli_error($koneksi));
}

// --- 2. Data Notifikasi Dummy (Contoh Saja) ---
// Dalam implementasi nyata, data ini akan diambil dari tabel database `notifications`
$notifications = [
    [
        'id' => 1,
        'type' => 'order_update',
        'title' => 'Pesanan #12345 Selesai',
        'content' => 'Pesanan Anda dengan nomor #12345 telah berhasil diselesaikan dan tiba di tujuan. Silakan berikan rating!',
        'date' => '2025-07-05 10:30:00',
        'read' => false,
        'link' => 'order_confirmation.php?order_id=12345'
    ],
    [
        'id' => 3,
        'type' => 'account_security',
        'title' => 'Aktivitas Login Baru',
        'content' => 'Terdeteksi login dari perangkat atau lokasi baru. Jika ini bukan Anda, segera ubah password Anda.',
        'date' => '2025-07-03 08:45:00',
        'read' => true,
        'link' => 'profile.php' // Link ke halaman profil atau pengaturan keamanan
    ],
    [
        'id' => 4,
        'type' => 'order_update',
        'title' => 'Pesanan #12344 Dikirim',
        'content' => 'Pesanan Anda dengan nomor #12344 telah dikirimkan. Lacak pengiriman Anda di sini.',
        'date' => '2025-07-02 18:00:00',
        'read' => true,
        'link' => '#' // Link ke detail pelacakan pesanan
    ]
];

// Tutup koneksi database
if (isset($koneksi)) {
    mysqli_close($koneksi);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Notifikasi - Thriftpreelove</title>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"/>
    <style>
        /* Gaya dasar */
        body {
            font-family: sans-serif;
            margin: 0;
            background-color: #f0f2f5; /* Warna background lebih terang */
        }

        /* Navbar Styling */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: black;
            color: white;
            padding: 10px 20px;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }

        .navbar .logo a {
            color: white;
            font-size: 20px;
            font-weight: bold;
            text-decoration: none;
        }

        .nav-links {
            display: flex;
            gap: 20px;
            list-style: none;
            margin: 0 auto;
            flex-grow: 1;
            justify-content: center;
        }

        .nav-links li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .search-container-inline {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }

        .search-container-inline input[type="text"] {
            padding: 8px 15px;
            border: none;
            border-radius: 20px 0 0 20px;
            outline: none;
            width: 220px;
            background-color: white;
            color: #333;
            font-size: 16px;
        }

        .search-container-inline button {
            background-color: #e0b0ff;
            border: none;
            padding: 8px 15px;
            border-radius: 0 20px 20px 0;
            margin-left: -1px;
            cursor: pointer;
            color: black;
            transition: background-color 0.3s ease;
            font-size: 16px;
        }

        .search-container-inline button:hover {
            background-color: #cc99ff;
        }

        .nav-icons {
          display: flex;
          align-items: center;
          gap: 15px;
        }

        .nav-icons a {
          color: white;
          font-size: 18px;
          text-decoration: none;
          transition: color 0.3s ease;
        }

        .nav-icons a:hover {
          color: #e0b0ff;
        }

        .auth-links {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-left: 15px;
        }

        .auth-links a {
            background-color: #4a4a4a;
            padding: 8px 15px;
            border-radius: 8px;
            color: white;
            text-decoration: none;
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 80px;
            transition: background-color 0.3s ease, transform 0.1s ease;
        }

        .auth-links a:hover {
            background-color: #666;
            transform: translateY(-1px);
        }

        /* Layout Utama Halaman Profil */
        .profile-page-container {
            display: flex;
            gap: 20px;
            padding: 80px 20px 40px; /* Padding top disesuaikan dengan navbar, bottom untuk footer */
            max-width: 1200px;
            margin: 0 auto;
            align-items: flex-start; /* Align items to the top */
        }

        /* Sidebar Profil Kiri */
        .profile-sidebar {
            flex: 0 0 250px; /* Lebar tetap 250px */
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 20px;
            box-sizing: border-box;
            position: sticky; /* Sticky sidebar */
            top: 100px; /* Sesuaikan dengan tinggi navbar + sedikit margin */
        }

        .profile-avatar-area {
            display: flex;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }

        .profile-avatar-area img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e0b0ff;
            margin-right: 15px;
        }

        .profile-username-edit {
            display: flex;
            flex-direction: column;
        }

        .profile-username-edit span {
            font-weight: bold;
            font-size: 1.1em;
            color: #333;
            margin-bottom: 5px;
        }

        .profile-username-edit a {
            color: #555;
            text-decoration: none;
            font-size: 0.9em;
            transition: color 0.3s ease;
        }

        .profile-username-edit a:hover {
            color: #e0b0ff;
        }

        .sidebar-menu ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu li a {
            display: block;
            padding: 12px 15px;
            color: #555;
            text-decoration: none;
            font-weight: 500;
            border-radius: 5px;
            transition: background-color 0.2s ease, color 0.2s ease;
        }

        .sidebar-menu li a:hover,
        .sidebar-menu li a.active {
            background-color: #f0f2f5;
            color: #e0b0ff;
            font-weight: bold;
        }
        .sidebar-menu li a i {
            margin-right: 10px;
            font-size: 1.1em;
            width: 20px; /* Fixed width for icon alignment */
            text-align: center;
        }

        /* Konten Utama Notifikasi */
        .profile-content { /* Menggunakan class yang sama dengan profile.php untuk konsistensi */
            flex: 1;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 25px;
            box-sizing: border-box;
        }

        .notification-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }

        .notification-header h2 {
            margin: 0;
            font-size: 2em;
            color: #333;
        }

        .notification-header .mark-all-read {
            background-color: #e0b0ff;
            color: black;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .notification-header .mark-all-read:hover {
            background-color: #cc99ff;
        }

        .notification-list .notification-item {
            display: flex;
            align-items: flex-start;
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
            background-color: #fff;
            transition: background-color 0.2s ease;
            position: relative;
        }

        .notification-list .notification-item:last-child {
            border-bottom: none;
        }

        .notification-list .notification-item:hover {
            background-color: #fcfcfc;
        }

        .notification-list .notification-item.unread {
            background-color: #ecf6ff; /* Warna latar belakang untuk notifikasi belum dibaca */
            border-left: 5px solid #e0b0ff; /* Garis samping untuk notifikasi belum dibaca */
            padding-left: 10px; /* Sesuaikan padding setelah border-left */
        }
        .notification-list .notification-item.unread .notification-title {
            font-weight: bold; /* Judul lebih tebal untuk belum dibaca */
            color: #333;
        }

        .notification-icon {
            font-size: 1.5em;
            color: #e0b0ff;
            margin-right: 15px;
            width: 30px; /* Fixed width for icon */
            text-align: center;
        }
        .notification-icon.order_update { color: #2ecc71; } /* Green for order updates */
        .notification-icon.promotion { color: #f39c12; } /* Orange for promotions */
        .notification-icon.account_security { color: #e74c3c; } /* Red for security */

        .notification-content {
            flex-grow: 1;
        }

        .notification-title {
            font-size: 1.1em;
            color: #555;
            margin-bottom: 5px;
        }

        .notification-text {
            font-size: 0.95em;
            color: #777;
            line-height: 1.5;
            margin-bottom: 5px;
        }

        .notification-date {
            font-size: 0.85em;
            color: #aaa;
            text-align: right; /* Posisikan tanggal ke kanan */
            position: absolute;
            top: 15px;
            right: 15px;
        }

        .no-notifications {
            text-align: center;
            padding: 30px;
            color: #777;
            font-size: 1.1em;
            background-color: #f8f8f8;
            border-radius: 8px;
        }

        /* Footer */
        footer {
            background-color: #222;
            color: white;
            text-align: center;
            padding: 15px;
            margin-top: 20px;
        }

        /* Responsive adjustments (copy from profile.php) */
        @media (max-width: 768px) {
            .profile-page-container {
                flex-direction: column;
                padding-top: 70px;
            }
            .profile-sidebar {
                width: 100%;
                position: static;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>

    <header>
        <nav class="navbar">
            <div class="logo">
                <a href="index.html#home">thriftpreelove.</a>
            </div>
            <ul class="nav-links">
                <li><a href="index.html#home">Home</a></li>
                <li><a href="index.html#tentang-kami">Tentang Kami</a></li>
                <li><a href="produk.php">Produk</a></li>
                <li><a href="index.html#kontak">Kontak</a></li>
            </ul>

            <div class="search-container-inline">
                <form action="search.php" method="GET" style="display: flex;">
                    <input type="text" name="query" placeholder="Cari produk...">
                    <button type="submit"><i class="fas fa-search"></i></button>
                </form>
            </div>

            <div style="display: flex; align-items: center">
                <div class="nav-icons">
                    <a href="cart.php" class="cart-icon" title="Lihat Keranjang">
                        <i class="fas fa-shopping-cart"></i>
                    </a>
                </div>

                <div class="auth-links">
                    <a href="profile.php">Profil</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <div class="profile-page-container">
            <aside class="profile-sidebar">
                <?php if ($user_data): ?>
                <div class="profile-avatar-area">
                    <img src="img/cintaku.jpg" alt="User Avatar"> <div class="profile-username-edit">
                        <span><?php echo htmlspecialchars($user_data['username']); ?></span>
                        <a href="edit_profile.php"><i class="fas fa-edit"></i> Ubah Profil</a>
                    </div>
                </div>

                <nav class="sidebar-menu">
                    <ul>
                        <li><a href="profile.php"><i class="fas fa-user"></i> Akun Saya</a></li>
                        <li><a href="profile.php?status=all"><i class="fas fa-clipboard-list"></i> Pesanan Saya</a></li>
                        <li><a href="notifications.php" class="active"><i class="fas fa-bell"></i> Notifikasi</a></li>
                        </ul>
                </nav>
                <?php else: ?>
                    <p style="text-align: center; color: #777;">Memuat profil...</p>
                <?php endif; ?>
            </aside>

            <section class="profile-content">
                <div class="notification-header">
                    <h2>Notifikasi</h2>
                    <button class="mark-all-read">Tandai Semua Sudah Dibaca</button>
                </div>

                <div class="notification-list">
                    <?php if (!empty($message)): ?>
                        <p style="color: red; text-align: center; font-weight: bold;"><?php echo htmlspecialchars($message); ?></p>
                    <?php endif; ?>

                    <?php if (!empty($notifications)): ?>
                        <?php foreach ($notifications as $notification): ?>
                            <a href="<?php echo htmlspecialchars($notification['link'] ?? '#'); ?>" class="notification-item <?php echo $notification['read'] ? '' : 'unread'; ?>">
                                <div class="notification-icon <?php echo htmlspecialchars($notification['type']); ?>">
                                    <?php
                                        // Ganti ikon berdasarkan jenis notifikasi
                                        if ($notification['type'] == 'order_update') {
                                            echo '<i class="fas fa-box"></i>';
                                        } elseif ($notification['type'] == 'promotion') {
                                            echo '<i class="fas fa-percent"></i>';
                                        } elseif ($notification['type'] == 'account_security') {
                                            echo '<i class="fas fa-shield-alt"></i>';
                                        } else {
                                            echo '<i class="fas fa-info-circle"></i>'; // Default
                                        }
                                    ?>
                                </div>
                                <div class="notification-content">
                                    <div class="notification-title"><?php echo htmlspecialchars($notification['title']); ?></div>
                                    <div class="notification-text"><?php echo htmlspecialchars($notification['content']); ?></div>
                                    <div class="notification-date"><?php echo date('d M Y H:i', strtotime($notification['date'])); ?></div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-notifications">
                            <i class="fas fa-bell-slash fa-3x" style="margin-bottom: 15px; color: #ccc;"></i>
                            <p>Tidak ada notifikasi baru untuk Anda.</p>
                            <p>Kami akan memberitahu Anda tentang pembaruan penting di sini.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </main>

    <footer>
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> Thriftpreelove. Semua Hak Dilindungi.</p>
        </div>
    </footer>
</body>
</html>
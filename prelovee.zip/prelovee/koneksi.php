<?php
$host = "localhost";
$user = "root"; // Ganti jika username database kamu berbeda
$pass = "";     // Ganti jika ada password database
$db   = "preelove_db"; // Ganti sesuai nama database kamu

$koneksi = mysqli_connect($host, $user, $pass, $db);

// Cek koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>

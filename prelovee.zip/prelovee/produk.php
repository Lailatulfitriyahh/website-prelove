<?php
// Pastikan file koneksi.php sudah ada dan berisi detail koneksi database Anda
include 'koneksi.php';

// Query untuk mengambil semua produk dari database
$query_produk = "SELECT id_produk, nama_produk, harga, gambar_produk FROM produk ORDER BY nama_produk ASC";
$result_produk = mysqli_query($koneksi, $query_produk);

// Cek jika ada error dalam query
if (!$result_produk) {
    die("Query produk gagal: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Semua Produk - Thriftpreelove</title>
    <link rel="stylesheet" href="css/style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
    <style>
      body {
        font-family: sans-serif;
        margin: 0;
        background-color: #f9f9f9;
      }

      .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: black;
        color: white;
        padding: 10px 20px;
        position: fixed;
        width: 100%;
        top: 0;
        left: 0;
        z-index: 1000;
      }

      .navbar .logo a {
        color: white;
        font-size: 20px;
        font-weight: bold;
        text-decoration: none;
      }

      .nav-links {
        display: flex;
        gap: 20px;
        list-style: none;
        margin: 0 auto; /* Added to center nav links */
        flex-grow: 1; /* Allows nav links to grow and push search/auth links */
        justify-content: center; /* Centers links within nav-links container */
      }

      .nav-links li a {
        color: white;
        text-decoration: none;
        font-weight: bold;
      }

      /* Consistent search container styling */
      .search-container-inline { /* Renamed for consistency with index.html */
        display: flex;
        align-items: center;
        margin-right: 20px; /* Adjusted margin */
      }

      .search-container-inline input[type="text"] {
        padding: 8px 15px; /* Adjusted padding for consistency */
        border: none;
        border-radius: 20px 0 0 20px; /* Adjusted border-radius */
        outline: none;
        width: 220px; /* Adjusted width for consistency */
        background-color: white;
        color: #333;
        font-size: 16px; /* Adjusted font-size for consistency */
      }

      .search-container-inline button {
        background-color: #e0b0ff;
        border: none;
        padding: 8px 15px; /* Adjusted padding for consistency */
        border-radius: 0 20px 20px 0; /* Adjusted border-radius */
        margin-left: -1px; /* Adjusted margin for consistency */
        cursor: pointer;
        color: black;
        transition: background-color 0.3s ease;
        font-size: 16px; /* Adjusted font-size for consistency */
      }

      .search-container-inline button:hover {
        background-color: #cc99ff;
      }

      /* START: MODIFIED STYLING FOR PROFILE/LOGOUT BUTTONS */
      .auth-links {
        display: flex;
        align-items: center;
        gap: 10px; /* Space between buttons */
        margin-left: 15px;
      }

      /* Base style for both Profil and Logout buttons */
      .auth-links a {
        background-color: #4a4a4a; /* Dark gray background as in image */
        padding: 8px 15px; /* Adjust padding for button size */
        border-radius: 8px; /* Rounded corners */
        color: white; /* White text */
        text-decoration: none;
        font-weight: bold;
        display: inline-flex;
        align-items: center;
        justify-content: center; /* Center text within the button */
        min-width: 80px; /* Ensure a minimum width for button uniformity */
        transition: background-color 0.3s ease, transform 0.1s ease;
      }

      .auth-links a:hover {
        background-color: #666; /* Slightly lighter gray on hover */
        transform: translateY(-1px); /* Slight lift on hover */
      }
      /* END: MODIFIED STYLING FOR PROFILE/LOGOUT BUTTONS */

      /* Gaya khusus untuk halaman produk */
      .all-products-section {
        padding: 80px 20px; /* Sesuaikan padding-top dengan tinggi navbar */
        text-align: center;
        max-width: 1200px;
        margin: 20px auto;
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      }

      .all-products-section h2 {
        font-size: 2.8em;
        margin-bottom: 30px;
        color: #333;
      }

      .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 25px;
        justify-content: center;
      }

      .product-item {
        background: #f9f9f9;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
      }

      .product-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
      }

      .product-item img {
        width: 100%;
        height: 200px;
        object-fit: cover;
        border-radius: 6px;
        margin-bottom: 10px;
      }

      .product-item h3 {
        font-size: 1.3em;
        margin-bottom: 8px;
        color: #333;
      }

      .product-item p {
        font-size: 1.1em;
        font-weight: bold;
        color: #e0b0ff;
        margin-bottom: 15px;
      }

      .cta-button {
        background-color: #e0b0ff;
        border: none;
        padding: 10px 20px;
        border-radius: 20px;
        font-weight: bold;
        cursor: pointer;
        display: inline-block;
        text-decoration: none;
        color: black;
        transition: background-color 0.3s ease;
      }

      .cta-button:hover {
        background-color: #cc99ff;
      }

      footer {
        background-color: #222;
        color: white;
        text-align: center;
        padding: 15px;
        margin-top: 40px;
      }
    </style>
  </head>
  <body>
    <header>
      <nav class="navbar">
        <div class="logo">
          <a href="index.html#home">thriftpreelove.</a>
        </div>
        <ul class="nav-links">
          <li><a href="index.html#home">Home</a></li>
          <li><a href="index.html#tentang-kami">Tentang Kami</a></li>
          <li><a href="produk.php">Produk</a></li>
          <li><a href="index.html#kontak">Kontak</a></li>
        </ul>

        <div class="search-container-inline">
          <form action="search.php" method="GET" style="display: flex;">
              <input type="text" name="query" placeholder="Cari produk...">
              <button type="submit"><i class="fas fa-search"></i></button>
          </form>
        </div>

        <div style="display: flex; align-items: center">
          <div class="nav-icons">
            <a href="cart.php" class="cart-icon" title="Lihat Keranjang">
              <i class="fas fa-shopping-cart"></i>
            </a>
          </div>

          <div class="auth-links">
            <a href="profile.php">Profil</a>
            <a href="logout.php">Logout</a>
          </div>
        </div>
      </nav>
    </header>

    <main>
      <section class="all-products-section">
        <h2>Koleksi Lengkap Kami</h2>
        <?php if (mysqli_num_rows($result_produk) > 0): ?>
        <div class="product-grid">
          <?php while($row = mysqli_fetch_assoc($result_produk)): ?>
          <div class="product-item">
            <img src="img/<?php echo htmlspecialchars($row['gambar_produk']); ?>" alt="<?php echo htmlspecialchars($row['nama_produk']); ?>" />
            <h3><?php echo htmlspecialchars($row['nama_produk']); ?></h3>
            <p>Rp <?php echo number_format($row['harga'], 0, ',', '.'); ?></p>
            <a href="detail_produk.php?id_produk=<?php echo htmlspecialchars($row['id_produk']); ?>" class="cta-button">Lihat Detail</a>
          </div>
          <?php endwhile; ?>
        </div>
        <?php else: ?>
        <p>Belum ada produk yang tersedia saat ini.</p>
        <?php endif; ?>
      </section>
    </main>

    <footer>
      <div class="container">
        <p>&copy; 2025 Thriftpreelove. Semua Hak Dilindungi.</p>
      </div>
    </footer>
  </body>
</html>

<?php
// Tutup koneksi database setelah selesai
mysqli_close($koneksi);
?>
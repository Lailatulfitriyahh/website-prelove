<?php
include 'koneksi.php'; // Pastikan ini mengarah ke file koneksi database Anda

$search_query = "";
$result_produk = null;
$message = "";

// Cek apakah ada query pencarian yang dikirimkan melalui GET
if (isset($_GET['query']) && !empty(trim($_GET['query']))) {
    $search_query = mysqli_real_escape_string($koneksi, trim($_GET['query']));

    // Query untuk mencari produk berdasarkan nama_produk atau deskripsi_produk
    // Menggunakan LIKE %...% untuk pencarian parsial (mengandung kata kunci)
    $query_produk = "SELECT id_produk, nama_produk, harga, gambar_produk, deskripsi_produk
                     FROM produk
                     WHERE nama_produk LIKE '%$search_query%' OR deskripsi_produk LIKE '%$search_query%'
                     ORDER BY nama_produk ASC";

    $result_produk = mysqli_query($koneksi, $query_produk);

    if (!$result_produk) {
        die("Query pencarian gagal: " . mysqli_error($koneksi));
    }

    if (mysqli_num_rows($result_produk) == 0) {
        $message = "Tidak ditemukan produk untuk pencarian '<strong>" . htmlspecialchars($search_query) . "</strong>'.";
    } else {
        $message = "Hasil pencarian untuk '<strong>" . htmlspecialchars($search_query) . "</strong>':";
    }

} else {
    // Jika tidak ada query atau query kosong, tampilkan pesan
    $message = "Silakan masukkan kata kunci pencarian.";
}
?>

<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Hasil Pencarian - Thriftpreelove</title>
    <link rel="stylesheet" href="css/style.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
    <style>
      body {
        font-family: sans-serif;
        margin: 0;
        background-color: #f9f9f9;
      }

      .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: black;
        color: white;
        padding: 10px 20px;
        position: fixed;
        width: 100%;
        top: 0;
        left: 0;
        z-index: 1000;
      }

      .navbar .logo a {
        color: white;
        font-size: 20px;
        font-weight: bold;
        text-decoration: none;
      }

      .nav-links {
        display: flex;
        gap: 20px;
        list-style: none;
        margin: 0 auto;
        flex-grow: 1;
        justify-content: center;
      }

      .nav-links li a {
        color: white;
        text-decoration: none;
        font-weight: bold;
      }

      .search-container-inline {
        display: flex;
        align-items: center;
        margin-right: 20px;
      }

      .search-container-inline input[type="text"] {
        padding: 8px 15px;
        border: none;
        border-radius: 20px 0 0 20px;
        outline: none;
        width: 220px;
        background-color: white;
        color: #333;
        font-size: 16px;
      }

      .search-container-inline button {
        background-color: #e0b0ff;
        border: none;
        padding: 8px 15px;
        border-radius: 0 20px 20px 0;
        margin-left: -1px;
        cursor: pointer;
        color: black;
        transition: background-color 0.3s ease;
        font-size: 16px;
      }

      .search-container-inline button:hover {
        background-color: #cc99ff;
      }

      /* START: Consistent Styling for Profil/Logout Buttons */
      .auth-links {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-left: 15px;
      }

      .auth-links a {
        background-color: #4a4a4a;
        padding: 8px 15px;
        border-radius: 8px;
        color: white;
        text-decoration: none;
        font-weight: bold;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 80px;
        transition: background-color 0.3s ease, transform 0.1s ease;
      }

      .auth-links a:hover {
        background-color: #666;
        transform: translateY(-1px);
      }
      /* END: Consistent Styling for Profil/Logout Buttons */

      /* Gaya khusus untuk halaman hasil pencarian */
      .search-results-section {
        padding: 80px 20px; /* Sesuaikan padding-top dengan tinggi navbar */
        text-align: center;
        max-width: 1200px;
        margin: 20px auto;
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      }

      .search-results-section h2 {
        font-size: 2.8em;
        margin-bottom: 20px;
        color: #333;
      }

      .search-results-section p.message {
          font-size: 1.2em;
          color: #555;
          margin-bottom: 30px;
      }

      .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 25px;
        justify-content: center;
      }

      .product-item {
        background: #f9f9f9;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
      }

      .product-item:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
      }

      .product-item img {
        width: 100%;
        height: 200px;
        object-fit: cover;
        border-radius: 6px;
        margin-bottom: 10px;
      }

      .product-item h3 {
        font-size: 1.3em;
        margin-bottom: 8px;
        color: #333;
      }

      .product-item p {
        font-size: 1.1em;
        font-weight: bold;
        color: #e0b0ff;
        margin-bottom: 15px;
      }

      .cta-button {
        background-color: #e0b0ff;
        border: none;
        padding: 10px 20px;
        border-radius: 20px;
        font-weight: bold;
        cursor: pointer;
        display: inline-block;
        text-decoration: none;
        color: black;
        transition: background-color 0.3s ease;
      }

      .cta-button:hover {
        background-color: #cc99ff;
      }

      footer {
        background-color: #222;
        color: white;
        text-align: center;
        padding: 15px;
        margin-top: 40px;
      }
    </style>
  </head>
  <body>
    <header>
      <nav class="navbar">
        <div class="logo">
          <a href="index.html#home">thriftpreelove.</a>
        </div>
        <ul class="nav-links">
          <li><a href="index.html#home">Home</a></li>
          <li><a href="index.html#tentang-kami">Tentang Kami</a></li>
          <li><a href="produk.php">Produk</a></li>
          <li><a href="index.html#kontak">Kontak</a></li>
        </ul>

        <div class="search-container-inline">
          <form action="search.php" method="GET" style="display: flex;">
              <input type="text" name="query" placeholder="Cari produk..." value="<?php echo htmlspecialchars($search_query); ?>">
              <button type="submit"><i class="fas fa-search"></i></button>
          </form>
        </div>

        <div style="display: flex; align-items: center">
          <div class="nav-icons">
            <a href="cart.php" class="cart-icon" title="Lihat Keranjang">
              <i class="fas fa-shopping-cart"></i>
            </a>
          </div>

          <div class="auth-links">
            <a href="profile.php">Profil</a>
            <a href="logout.php">Logout</a>
          </div>
        </div>
      </nav>
    </header>

    <main>
      <section class="search-results-section">
        <h2>Hasil Pencarian</h2>
        <p class="message"><?php echo $message; ?></p>

        <?php if ($result_produk && mysqli_num_rows($result_produk) > 0): ?>
        <div class="product-grid">
          <?php while($row = mysqli_fetch_assoc($result_produk)): ?>
          <div class="product-item">
            <img src="img/<?php echo htmlspecialchars($row['gambar_produk']); ?>" alt="<?php echo htmlspecialchars($row['nama_produk']); ?>" />
            <h3><?php echo htmlspecialchars($row['nama_produk']); ?></h3>
            <p>Rp <?php echo number_format($row['harga'], 0, ',', '.'); ?></p>
            <a href="detail_produk.php?id_produk=<?php echo htmlspecialchars($row['id_produk']); ?>" class="cta-button">Lihat Detail</a>
          </div>
          <?php endwhile; ?>
        </div>
        <?php elseif ($result_produk && mysqli_num_rows($result_produk) == 0): ?>
            <?php endif; ?>
        <div style="margin-top: 30px;">
             <a href="produk.php" class="cta-button" style="background-color: #222; color: #fff">
                <i class="fas fa-store"></i> Lihat Semua Produk
            </a>
        </div>
      </section>
    </main>

    <footer>
      <div class="container">
        <p>&copy; 2025 Thriftpreelove. Semua Hak Dilindungi.</p>
      </div>
    </footer>
  </body>
</html>

<?php
// Tutup koneksi database setelah selesai
if (isset($koneksi)) {
    mysqli_close($koneksi);
}
?>
<?php
session_start();

// Check if user is logged in, otherwise redirect to login page
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Thriftpreelove</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <a href="#">thriftpreelove.</a>
            </div>
            <ul class="nav-links">
                <li><a href="#">Home</a></li>
                <li><a href="#">Tentang Kami</a></li>
                <li><a href="#">Produk</a></li>
                <li><a href="#">Kontak</a></li>
            </ul>
            <div class="nav-icons">
                <a href="#" class="search-icon"><i class="fas fa-search"></i></a>
                <a href="#" class="cart-icon"><i class="fas fa-shopping-cart"></i></a>
                <div class="auth-links">
                    <a href="dashboard.php" id="dashboardLink">Dashboard</a>
                    <a href="logout.php" id="logoutLink">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main style="padding-top: 80px; text-align: center;">
        <h1>Selamat datang, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h1>
        <p>Ini adalah halaman dashboard Anda. Di sini Anda bisa melihat informasi akun, pesanan, dll.</p>
        <p><a href="logout.php">Logout</a></p>
    </main>

    <script src="js/script.js"></script> </body>
</html>